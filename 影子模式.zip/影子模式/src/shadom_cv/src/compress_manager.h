#include <archive.h>
#include <archive_entry.h>

class CompressManager {
 public:
  CompressManager();
  ~CompressManager();

  CompressManager(const CompressManager&) = delete;
  CompressManager& operator=(const CompressManager&) = delete;

  void compress_file(const char* file_name);
 private:
  archive* ar_;
  archive_entry* entry_;
};
