#ifndef UPLOAD_MANAGER_H
#define UPLOAD_MANAGER_H

#include "data_manager_interface.h"
#include "shadow_utils.h"

#include <fstream>

class UploadManager : public DataManagerInterface {
 public:
  UploadManager();
  ~UploadManager();

  UploadManager(const UploadManager&) = delete;
  UploadManager& operator=(const UploadManager&) = delete;

  bool HandleData(enum HandleType, const Data&, const Strategy&) override;
  Data WrappedData() override;

  void UpdateFile(const std::string& path) { local_path_ = std::move(path); }

 private:
  bool Upload(const Data& data, const Strategy& strategy); 
  bool UploadSignal(const Data& data, const Strategy& strategy);
  bool UploadImage(const Data& data, const Strategy& strategy);
  
  std::string local_path_;
  std::ofstream log_;
};

#endif // !UPLOAD_MANAGER_H
