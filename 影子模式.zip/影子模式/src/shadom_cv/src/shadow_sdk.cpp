#include "shadow_global.h"
#include "shadow_utils.h"

namespace shadow {

void CANmsgsCallback(const can_msgs::Frame& msg) {
  if(msg.id == 0x350) {
    can::CANsub_msgs_ID_0X350.data = msg.data;       
    can::msgBrakePedalPosition.data = float(1 * msg.data[0]);//match jiyu 
    // ROS_INFO("msgBrakePedalPosition:[%f]", can::msgBrakePedalPosition.data);  
    can::msgAccelPedalPosition.data = float(msg.data[2]);//need to update
   //  ROS_INFO("msgAccelPedalPosition:[%f]", can::msgAccelPedalPosition.data);  
    can::msgVehicleSpeed.data = float(0.1 * ((msg.data[5] << 8) + msg.data[4]));//match jiyu          
   //  ROS_INFO("msgVehicleSpeed:[%f]", can::msgVehicleSpeed.data);  
    // trigger::tgr.GetTriggerLog()->INFO(
    //     "can::msgVehicleSpeed = " + std::to_string(can::msgVehicleSpeed.data));
    
    can::current_time_0X350 = GetUnixTime();
    float delta_time = ((can::current_time_0X350 - can::prev_time_0X350) * 10e-3) / 3600;
    can::msgVehicleAccel.data =  float((can::msgVehicleSpeed.data - can::prev_msgVehicleSpeed.data) / delta_time);
    can::prev_msgVehicleSpeed.data = can::msgVehicleSpeed.data;
    can::prev_time_0X350 = can::current_time_0X350;
    // std::cout << delta_time << std::endl;
    // ROS_INFO("msgVehicleAccel:[%f]",can::msgVehicleAccel.data);

    can::msgShakeLStBool.data = int(msg.data[6] >> 7);//shake_L
    // ROS_INFO("msgShakeLStBool:[%d]",can::msgShakeLStBool.data);  
    can::msgBrakeModeStBool.data = int(int(msg.data[6] >> 6) & 0b01);   //brake_mode
    // ROS_INFO("msgBrakeModeStBool:[%d]", can::msgBrakeModeStBool.data);  
    can::msgGearPosition.data = int(int(msg.data[6] >> 4) & 0b0011);//gear
     //ROS_INFO("msgGearPosition:[%d]", can::msgGearPosition.data);  
  }
  else if(msg.id == 0X351) {
    can::CANsub_msgs_ID_0X351.data = msg.data;    
    can::msgSteeringAngle.data = float(0.05 * ((msg.data[1] << 8) + msg.data[0]));///////need to test

    if (can::msgSteeringAngle.data > 900) {
      can::msgSteeringAngle.data = can::msgSteeringAngle.data - 3276.8;///////need to test
    }

    can::current_time_0X351 = GetUnixTime();
    float delta_time = (can::current_time_0X351 - can::prev_time_0X351) * 10e-3;
    can::msgSteeringSpeed.data = float((can::msgSteeringAngle.data - can::prev_msgSteeringAngle.data) / delta_time);
    can::prev_msgSteeringAngle.data = can::msgSteeringAngle.data;
    can::prev_time_0X351 = can::current_time_0X351;

   // ROS_INFO("msgSteeringAngle:[%f]", can::msgSteeringAngle.data);          
    can::msgmanAccelPedalPositionBool.data= int(msg.data[4] >> 7);//
    can::msgmanBrakePedalPositionBool.data= int((msg.data[4] >> 6) & 0b01);//            
    can::msgmanGearPositionBool.data= int((msg.data[4] >> 4) & 0b0001);//
    can::msgmanDriveModeBool.data= int((msg.data[4] >> 5) & 0b001);// 
    can::msgmanSteeringAngleBool.data= int(int(msg.data[5] >> 6) & 0b01);//   
    can::msgShakeHStBool.data= int(msg.data[6] >> 7);//  
    // ROS_INFO("msgShakeHStBool:[%d]", can::msgShakeHStBool.da ta);                
  }
  else if(msg.id == 0X370) { 
    can::CANsub_msgs_ID_0X370.data=msg.data;
    if (msg.data[1] == 0b00100000) {   
      can::msgTurnLLampStBool.data= 1;
      can::msgTurnRLampStBool.data= 0;
    }
    else if (msg.data[1] == 0b00010000) {   
      can::msgTurnLLampStBool.data= 0;
      can::msgTurnRLampStBool.data= 1;
    }
    else if (msg.data[1] == 0b00110000) {   
      can::msgTurnLLampStBool.data= 1;
      can::msgTurnRLampStBool.data= 1;
    }      
    else if (msg.data[1] == 0) {   
      can::msgTurnLLampStBool.data= 0;
      can::msgTurnRLampStBool.data= 0;
    }            
    //ROS_INFO("msgTurnLLampStBool:[%d]", can::msgTurnLLampStBool.data);  
    //ROS_INFO("msgTurnRLampStBool:[%d]", can::msgTurnRLampStBool.data);  
  }  
  else if(msg.id == 0X352) { 
    can::CANsub_msgs_ID_0X352.data = msg.data;    
    can::msgLimSpdSt.data = float((msg.data[0] & 0b00001111) * 5.0);
    // ROS_INFO("msgLimSpdSt:[%f]", can::msgLimSpdSt.data);  
  }
  else if(msg.id == 0X360) {
    can::CANsub_msgs_ID_0X360.data = msg.data;
    can::msgHornBool.data = int((msg.data[1] >> 1) & 0b0000001);
    can::msgDblFlashLampBool.data = int((msg.data[1] >> 6) & 0b01);
    
    can::msgHeadLampBool.data = int(msg.data[1] >> 7);
    
    can::current_time_0X360 = GetUnixTime();
    float delta_time = can::current_time_0X360 - can::prev_time_0X360;
    if(can::msgHeadLampBool.data && can::prev_msgHeadLampBool.data &&
        delta_time < 1000) {
      can::msgDblHeadLampBool.data = 1;
    }
    else {
      can::msgDblHeadLampBool.data = 0;
    }
    can::prev_msgHeadLampBool.data = can::msgHeadLampBool.data;
    can::prev_time_0X360 = can::current_time_0X360;
  }
  else if(msg.id == 0X359) {
    can::CANsub_msgs_ID_0X359.data = msg.data;
    can::msgEHBBrkReqWarnBool.data = int(msg.data[0]  & 0b00000001);
    can::msgEHBCANBusOffBool.data = int(msg.data[0] >> 1  & 0b0000001);
    can::msgEHBISnsrFltBool.data = int(msg.data[0] >> 2 & 0b000001);
    can::msgEHBLoadMismatchFltBool.data = int(msg.data[0] >> 3  & 0b00001);
    can::msgEHBMotPosnFltBool.data = int(msg.data[0] >> 4  & 0b0001);
    can::msgEHBNTCFltLv1Bool.data = int(msg.data[0] >> 5  & 0b001);
    can::msgEHBNTCFltLv2Bool.data = int(msg.data[0] >> 6  & 0b01);
    can::msgEHBOverIFltBool.data = int(msg.data[0] >> 7 & 0b1);
    can::msgEHBOverTempWarnBool.data = int(msg.data[1] & 0b00000001);
    can::msgEHBPCtrlVibLv1Bool.data = int(msg.data[1] >> 1 & 0b0000001);
    can::msgEHBPCtrlVibLv2Bool.data = int(msg.data[1] >> 2 & 0b000001);
    can::msgEHBPedlSnsrFltBothBool.data = int(msg.data[1] >> 3 & 0b00001);
    can::msgEHBPedlSnsrFltSingleBool.data = int(msg.data[1] >> 4 & 0b0001);
    can::msgEHBPFolwFltLv1Bool.data = int(msg.data[1] >> 5 & 0b001);
    can::msgEHBPFolwFltLv2Bool.data = int(msg.data[1] >> 6 & 0b01);
    can::msgEHBPSnsrFltBool.data = int(msg.data[1] >> 7 & 0b1);
    can::msgEHBPwrDrvrFltBool.data = int(msg.data[2]   & 0b00000001);
    can::msgEHBPwrSwtFltBool.data = int(msg.data[2] >> 1& 0b0000001);
    can::msgEHBUSplyHighLv1Bool.data = int(msg.data[2] >> 2 & 0b000001);
    can::msgEHBUSplyHighLv2Bool.data = int(msg.data[2] >> 3 & 0b00001);
    can::msgEHBUSplyLowLv1Bool.data = int(msg.data[2] >> 4 & 0b0001);
    can::msgEHBUSplyLowLv2Bool.data = int(msg.data[2] >> 5 & 0b001);
    can::msgEPSInhibitCode.data = int(((msg.data[2] >> 6) + (msg.data[3] << 2)) & 0b00000111);
    can::msgEPSStrFltCode.data = int(msg.data[2] >> 1 & 0b0000011);
  }
  
  
}

void shadowCMDCallback(const std_msgs::String::ConstPtr& msg) {
  std_msgs::String msgshadowCMD;
  ROS_INFO("shadowCMD:[%s]",msg->data.c_str());
  
  msgshadowCMD.data = msg->data; 
  trigger::tgr.UpdateStrategyFromCloudCMD(msgshadowCMD); 
}

void sentinelCMDCallback(const std_msgs::String::ConstPtr& msg) {
  ROS_INFO("sentinelCMD:[%s]",msg->data.c_str());
  trigger::tgr.EnableSentinel();
}

void userCMDCallback(const std_msgs::String::ConstPtr& msg) {
  std_msgs::String msgshadowCMD;
  ROS_INFO("userCMD:[%s]",msg->data.c_str());
  
  msgshadowCMD.data = msg->data; 
  trigger::tgr.CreateStrategyFromCloudCMD(msgshadowCMD);
}

} // !namespace shadow

int main(int argc, char** argv) {
  setlocale(LC_ALL,"");
  ros::init(argc,argv,"can_ros_mqtt");
  ros::NodeHandle n;

	ros::Subscriber sub_CANmsgs = n.subscribe("received_messages", 10, shadow::CANmsgsCallback);

	ros::Publisher shadow_pub = n.advertise<std_msgs::String>("/ShadowLog", 10); //
			
	ros::Subscriber sub_shadowCMD = n.subscribe("/ShadowCloudControl/fsd4_000001", 10, shadow::shadowCMDCallback);	

  ros::Subscriber sub_sentinelCMD = n.subscribe("/Sentinel/fsd4_000001", 10, shadow::sentinelCMDCallback);	

  ros::Subscriber sub_userCMD = n.subscribe("/Strategy/Create", 10, shadow::userCMDCallback);	

	ros::Rate loop_rate(30);

  std_msgs::String msgShadowLog;

  while(ros::ok()) {
    shadow::trigger::tgr.Sampler();
    shadow::trigger::tgr.SentryTriggered(shadow_pub, msgShadowLog);
    shadow::trigger::tgr.ShadowTriggered(shadow_pub, msgShadowLog);

    ros::spinOnce();
    loop_rate.sleep();
  }
  
  ros::spin();  
 
  return 0;
}



