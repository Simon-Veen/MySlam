#include "upload_manager.h"
#include "trigger_signal.h"

UploadManager::UploadManager() : DataManagerInterface() {}

UploadManager::~UploadManager() {}

bool UploadManager::HandleData(
    enum HandleType handle_type, const Data& data, const Strategy& strategy) {
  switch(handle_type) {
    case UPLOAD:
      return Upload(data, strategy);
    default:
      return false;
  }

  return false;
}

Data UploadManager::WrappedData() {
  Data data;

  data.flash_capture = &shadow::buffer::flashCapturesQueue.front();
  #ifdef FEEL_FRAME
    data.image = &shadow::buffer::framesQueue.front();
  #endif

  return data;
}

bool UploadManager::Upload(const Data& data, const Strategy& strategy) {
  log_.open(local_path_ + "LOG.txt", std::ios::out | std::ios::app);

  if(!UploadSignal(data, strategy)) { return false; }
  #ifdef FEEL_FRAME
    if(!UploadImage(data, strategy)) { return false; }
  #endif

  log_.close();
  
  return true;
}

bool UploadManager::UploadSignal(const Data& data, const Strategy& strategy) {
  std::string txt_content_per_line = "time: " + std::to_string(data.flash_capture->timestamp) +
	    " ECU_id: " + strategy.equipment_id +
	    " stragy_ID: " + std::to_string(strategy.id) +
	    " stragy_TYPE: " + strategy.type +
	    " VehicleSpeed: " + std::to_string(data.flash_capture->msgVehicleSpeed.data) +
	    " SteeringAngle:" + std::to_string(data.flash_capture->msgSteeringAngle.data) +
	    " AccelPedal:" + std::to_string(data.flash_capture->msgAccelPedalPosition.data) +
	    " BrakePedal:" + std::to_string(data.flash_capture->msgBrakePedalPosition.data) +
	    " Gear:" + std::to_string(data.flash_capture->msgGearPosition.data) +
	    " TurnLLamp:" + std::to_string(data.flash_capture->msgTurnLLampStBool.data) +
	    " TurnRLamp:" + std::to_string(data.flash_capture->msgTurnRLampStBool.data);

  log_ << txt_content_per_line << std::endl;
  
  return true;
}

bool UploadManager::UploadImage(const Data& data, const Strategy& strategy) {
  cv::imwrite(local_path_ + std::to_string(shadow::GetUnixTime()) + ".jpg", *data.image);

  return true;
}
