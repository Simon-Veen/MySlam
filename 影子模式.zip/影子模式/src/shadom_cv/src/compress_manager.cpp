#include "compress_manager.h"
#include <fcntl.h>
#include <iostream>

CompressManager::CompressManager() {}

CompressManager::~CompressManager() {}


void CompressManager::compress_file(const char* file_name)
{
    struct archive *a;
    struct archive_entry *entry;
    struct stat st;
    char buffer[BUFSIZ];
    int len;
    int fd;
    int ret;

    // 打开压缩文件
    a = archive_write_new();
    archive_write_add_filter_xz(a);
    archive_write_set_format_pax_restricted(a); // tar format
    archive_write_open_filename(a, "out.tar.xz");

    // 打开需要压缩的文件
    fd = open(file_name, O_RDONLY);
    fstat(fd, &st);
    if(!fd) { std::cout << "Failed Open." << std::endl; }

    // 创建entry结构体，添加到压缩归档文件
    entry = archive_entry_new();
    archive_entry_set_pathname(entry, file_name);
    archive_entry_set_size(entry, st.st_size);
    archive_entry_set_filetype(entry, AE_IFREG);
    archive_entry_set_perm(entry, 0644);

    // 写入entry到压缩归档文件
    archive_write_header(a, entry);

    // 逐个读取文件内容
    while ((len = read(fd, buffer, BUFSIZ)) > 0) {
        archive_write_data(a, buffer, len);
    }

    // 释放资源
    close(fd);
    archive_entry_free(entry);
    archive_write_close(a);
    archive_write_free(a);
}
