#include "shadow_trigger.h"
#include "shadow_global.h"
#include "shadow_constant.h"

#include <algorithm>
#include <thread>
#include <chrono>

namespace shadow {

ShadowTrigger::ShadowTrigger(const std::string& config_path) 
        : config_path_(config_path),
          enable_sentinel_(false),
          sampler_size_(0) {
  InitConfig();
  LoadStrategy();
  #ifdef FEEL_FRAME
    capture_.open("rtmp://139.196.255.179:1935/live/cam9");
    if(capture_.isOpened()) {
      trigger_log_.INFO("Camera is opened.", true); 
    }
    else {
      trigger_log_.INFO("Camera is not opened.", true);
    }
  #endif

  compress_manager_.compress_file("capture.jpg");
}

ShadowTrigger::~ShadowTrigger() {
  capture_.release();
}

void ShadowTrigger::UpdateStrategyFromCloudCMD(
    const std_msgs::String &msg) {
  std::vector<int> ids;
  std::vector<std::string> types;
  std::vector<float> weights;
  std::vector<int> hzs;
  std::vector<int> secs;
  std::vector<int> frequency_limit;
  std::string msgshadowCMD, eid, state;
  bool is_actived;
  int64_t time_start, time_stop;

  msgshadowCMD = msg.data;
  ParseShadowCMD<int>(ID, msgshadowCMD, ids);
  ParseShadowCMD(TYPE, msgshadowCMD, types);
  ParseShadowCMD(EID, msgshadowCMD, eid);
  ParseShadowCMD(TM_START, msgshadowCMD, time_start);
  ParseShadowCMD(TM_STOP, msgshadowCMD, time_stop);
  ParseShadowCMD<int>(FREQ, msgshadowCMD, frequency_limit);
  ParseShadowCMD(SWITCH, msgshadowCMD, state);
  ParseShadowCMD<float>(WEIGHT, msgshadowCMD, weights);
  ParseShadowCMD<int>(HZ, msgshadowCMD, hzs);
  ParseShadowCMD<int>(DURA, msgshadowCMD, secs, '+');
  eid = eid.substr(2);
  state = state.substr(0, state.size() - 1);
  
  std::transform(state.begin(), state.end(), state.begin(), [](unsigned char c) { return std::toupper(c); });

  is_actived = "ON" == state ? true : false;

  for(int i = 0; i < ids.size(); ++i) {
    if("09_003" == types[i] && !strategy::mapper.count(ids[i])) {
      trigger_log_.WARN("Can't update not created strategy ID " + std::to_string(ids[i]) + ".");
      continue;
    }

    if(strategy::mapper.count(ids[i]) && 
        strategy::mapper[ids[i]].judges.front() > MaxNestedJudgeNum 
            && "09_003" != types[i]) {
       trigger_log_.WARN("Can't modify customized strategy ID " + std::to_string(ids[i]) + ".");
       continue;
    }

    strategy::mapper[ids[i]].id = ids[i];
    strategy::mapper[ids[i]].equipment_id = eid;
    strategy::mapper[ids[i]].type = types[i];
    if("09_003" != types[i]) {
      Type2JudgeId(types[i], strategy::mapper[ids[i]].judges);
      strategy::mapper[ids[i]].combo.clear();
      int num_logic = strategy::mapper[ids[i]].judges.size() - 1;
      while(num_logic--) { strategy::mapper[ids[i]].combo.emplace_back(AND); }
    }
    strategy::mapper[ids[i]].weight = weights[i];
    strategy::mapper[ids[i]].hz = hzs[i];
    strategy::mapper[ids[i]].duration.before_seconds = secs[0];
    strategy::mapper[ids[i]].duration.after_seconds = secs[1];
    strategy::mapper[ids[i]].duration.time_start = time_start;
    strategy::mapper[ids[i]].duration.time_stop = time_stop;
    strategy::mapper[ids[i]].frequency.frequency_h_times_limit = frequency_limit[0];
    strategy::mapper[ids[i]].frequency.frequency_24h_times_limit = frequency_limit[1];
    strategy::mapper[ids[i]].is_actived = is_actived;
  }

  return;
}

void ShadowTrigger::CreateStrategyFromCloudCMD(
    const std_msgs::String &msg) {
  int strategy_id;
  std::string signal;
  enum Comparator comparator;
  float base;
  enum Logic logic;
  std::vector<CustomizedInfo> customied_info;

  std::vector<std::string> result;
  std::string value;
  
  std::stringstream ss(msg.data);
  while(std::getline(ss, value, ',')) {
    result.emplace_back(value); 
  }

  result.front() = result.front().substr(2);
  int size = result.back().size();
  result.back() = result.back().substr(0, size - 1);
  
  strategy_id = atoi(result[0].c_str());
  if(strategy::mapper.count(strategy_id)) {
    trigger_log_.WARN("Can't create existed strategy ID " + std::to_string(strategy_id) + ".");
    return;
  }

  for(int i = 1; i < result.size(); ++i) {
    signal = result[i++];
    if(">" == result[i]) { comparator = GREATER; }
    else if (">=" == result[i]) { comparator = GORE; }
    else if ("<" == result[i]) { comparator = LESS; }
    else if ("<=" == result[i]) { comparator = LORE; }
    else if ("==" == result[i]) { comparator = EQUAL; }
    ++i;
    base = atof(result[i++].c_str());
    
    CustomizedInfo info;
    info = { signal, comparator, base };
    customied_info.emplace_back(info);

    if(result.size() == i) { break; }
    
    if("&&" == result[i]) { logic = AND; }
    else if ("||" == result[i]) { logic = OR; }
    strategy::mapper[strategy_id].combo.emplace_back(logic);

  }

  std::vector<int> judges = strategy::judge.AddJudge(customied_info);
  strategy::mapper[strategy_id].id = strategy_id;
  strategy::mapper[strategy_id].judges.assign(judges.begin(), judges.end());

  SolidifyStrategyFromCloudCMD(
      strategy_id, judges, customied_info, strategy::mapper[strategy_id].combo);

  return;
}

void ShadowTrigger::SentryTriggered(
    ros::Publisher& pub, std_msgs::String& msg) {
  bool is_sentry_cmd;
  int64_t milliseconds;
  Strategy* strategy;

  is_sentry_cmd = false;
  strategy = nullptr;
  for(auto& sty : strategy::mapper) {
    auto it = std::find(sty.second.judges.begin(), sty.second.judges.end(), 1);
    if(it == sty.second.judges.end()) { continue; }

    milliseconds = GetUnixTime();
    if(sty.second.is_actived && 
        sty.second.frequency.valid(milliseconds) &&
            sty.second.duration.valid(milliseconds)) { 
      is_sentry_cmd = true;
      strategy = &sty.second;
      break;
    }
  }

  if(true == is_sentry_cmd && true == enable_sentinel_) {
    ShadowLogSentry(msg, 1, strategy->equipment_id);
    UpdateTriggeredTimes(*strategy, milliseconds);
    pub.publish(msg);
    
    trigger_log_.INFO("Sentry Triggered.", true);
  }
  enable_sentinel_ = false;
}

void ShadowTrigger::ShadowTriggered(ros::Publisher& pub, std_msgs::String& msg) {
  for(auto& sty : strategy::mapper) {
    int64_t milliseconds;

    milliseconds = GetUnixTime();

    if(!sty.second.is_actived || 
        !sty.second.frequency.valid(milliseconds) ||
            !sty.second.duration.valid(milliseconds)) { continue; }

    bool temp;
    int judge_index = 0;
    temp = strategy::judge.Result(sty.second.judges[judge_index]);
    for(const auto logic : sty.second.combo) {
      ++judge_index;
      switch(logic) {
        case AND:
          temp = temp && strategy::judge.Result(sty.second.judges[judge_index]);
          break;
        case OR:
          temp = temp || strategy::judge.Result(sty.second.judges[judge_index]);
          break;
        default:
          temp = false;
      }
    }

    if(temp) {
      ShadowLog(msg, sty.second);
      UpdateTriggeredTimes(sty.second, milliseconds);
      if(!msg.data.empty()) { pub.publish(msg); }

      trigger_log_.INFO("Strategy ID " + std::to_string(sty.first) + " Triggered.", true);
    }
  }
}

void ShadowTrigger::EnableSentinel() {
  enable_sentinel_ = true;
}

void ShadowTrigger::Sampler() {
  #ifdef FEEL_FRAME
    if(false == FrameSampler()) { return; }
  #endif

  SignalSampler();
  ++sampler_size_;

  if(sampler_size_ > MaxBufferSize * MaxFramesPerSec) {
    --sampler_size_;

    buffer::flashCapturesQueue.pop_front();
    #ifdef FEEL_FRAME
      buffer::framesQueue.pop_front();
    #endif
  }
}

void ShadowTrigger::InitConfig() {
  std::ifstream file(config_path_);
  std::string line;

  while (std::getline(file, line)) {
    std::stringstream ss(line);
    std::string cell, id, type;

    while (std::getline(ss, cell, ',')) {
      if (id.empty()) {
        id = cell;   
      } else {
        type = cell;
      }
    }
    
    id_type_[atoi(id.c_str())] = type;
  }
  file.close();
}

bool ShadowTrigger::SignalSampler() {
  FlashCapture flash_capture = {
    GetUnixTime(),
    can::msgVehicleSpeed,
    can::msgSteeringAngle,
    can::msgAccelPedalPosition,
    can::msgBrakePedalPosition,
    can::msgGearPosition,
    can::msgTurnLLampStBool,
    can::msgTurnRLampStBool,
    can::msgctrlSteeringAngle
  };

  buffer::flashCapturesQueue.push_back(flash_capture);
  return true;
}

bool ShadowTrigger::FrameSampler() {
  cv::Mat frame;
  capture_ >> frame;
  if(frame.empty()) { return false; }

  buffer::framesQueue.push_back(frame);
  return true;
}

void ShadowTrigger::ParseShadowCMD(
    enum ParseIndex parse_index, const std::string& src, std::string& dst) {
  int count;
  size_t pos, next_pos;
  
  pos = -1;
  next_pos = -1;
  count = parse_index;

  while (count--) {
    pos = next_pos;
    next_pos = src.find(',', pos + 1);
  }

  dst = std::move(src.substr(pos + 1, next_pos - pos -1));
}

void ShadowTrigger::PopSampler() {
  buffer::flashCapturesQueue.pop_front();
  #ifdef FEEL_FRAME
    buffer::framesQueue.pop_front();
  #endif
  --sampler_size_;
}

template<typename T>
void ShadowTrigger::ParseShadowCMD(
    enum ParseIndex parse_index, const std::string& src, 
        std::vector<T>& dst, const char mark) {
  std::string temp;
  std::string value;

  ParseShadowCMD(parse_index, src, temp);
  std::stringstream ss(temp);
  
  while(std::getline(ss, value, mark)) {
    dst.emplace_back(atof(value.c_str())); 
  }
}

void ShadowTrigger::ParseShadowCMD(enum ParseIndex parse_index, const std::string& src, 
    std::vector<std::string>& dst, const char mark) {
  std::string temp;
  std::string value;

  ParseShadowCMD(parse_index, src, temp);
  std::stringstream ss(temp);
  
  while(std::getline(ss, value, mark)) {
    dst.emplace_back(value); 
  }
}

void ShadowTrigger::ParseShadowCMD(
    enum ParseIndex parse_index, const std::string& src, int64_t& dst) {
  std::string temp;

  ParseShadowCMD(parse_index, src, temp);
  dst = std::move(_atoi64(temp.c_str()));
}

void ShadowTrigger::Type2JudgeId(
    const std::string& src, std::vector<int>& dst, const char mark) {
  dst.clear();

  std::string value;
  std::stringstream ss(src);
  
  while(std::getline(ss, value, mark)) {
    for(const auto it : id_type_) {
      if(value == it.second) { 
        dst.emplace_back(it.first);
      }
    }
  }
}

void ShadowTrigger::ShadowLogSentry(std_msgs::String& msgShadowLog, const int id, const std::string& eid) {
  const std::string stragy_type = id_type_[id];
  const std::string stragy_id = std::to_string(id);
  const std::string ECU_id = eid;
  int res;

  int64_t TIME_SHADOWLOG = GetUnixTime();
  std::string PATH_SAVE = "/home/nvidia/shadow_data/" + ECU_id + "type" + stragy_type + 
      "id" + stragy_id + "time"+std::to_string(TIME_SHADOWLOG) + "/";
  std::string PATH_SAVE_ALIYUN = "/root/shadow_data/" + ECU_id + "type"+stragy_type + 
      "id" + stragy_id + "time" + std::to_string(TIME_SHADOWLOG) + "/";
  std::string CMD1 = "mkdir " + PATH_SAVE;   
  const char* cmd1 = CMD1.data();
  res = system(cmd1); 
  //write txt
  std::ofstream outfile(PATH_SAVE + std::to_string(TIME_SHADOWLOG) + ".txt");
        
  msgShadowLog.data = ECU_id + "," + stragy_type + "," + stragy_id + "," + PATH_SAVE_ALIYUN + "," + std::to_string(TIME_SHADOWLOG);
  //cv::VideoCapture capture;
  cv::VideoCapture capture_front;
  cv::VideoCapture capture_left;
  cv::VideoCapture capture_right;
  cv::VideoCapture capture_dms;        
  //capture.open("rtsp://nvidia:nvidia@127.0.0.1:8554/test");
  //capture.open("rtmp://139.196.255.179:1935/live/cam1");
  capture_front.open("rtmp://139.196.255.179:1935/live/cam0");
  //capture_left.open("rtmp://139.196.255.179:1935/live/cam3");
  capture_left.open("rtmp://139.196.255.179:1935/live/cam0");
  //capture_left.open("rtmp://139.196.255.179:1935/live/cam0");

  capture_right.open("rtmp://139.196.255.179:1935/live/cam");
  //capture_right.open("rtmp://139.196.255.179:1935/live/cam4");
  
  capture_dms.open("rtmp://139.196.255.179:1935/live/cam0");
  //capture_dms.open("rtmp://139.196.255.179:1935/live/cam6");

  if(!capture_front.isOpened()) {
    std::cout << "Failed to open camera front" << std::endl;
  }
  if(!capture_left.isOpened()) {
    std::cout << "Failed to open camera left" << std::endl;
  }
  if(!capture_right.isOpened()) {
    std::cout << "Failed to open camera right" << std::endl;
  }
  if(!capture_dms.isOpened()) {
    std::cout << "Failed to open camera dms " << std::endl;
  }

  cv::Mat frame_front;
  cv::Mat frame_left;
  cv::Mat frame_right;
  cv::Mat frame_dms;
      
  capture_front >> frame_front;        
  capture_left >> frame_left;
  capture_right >> frame_right;
  capture_dms >> frame_dms;
        

  if(frame_front.empty()) {
    std::cout << "frame_front empty" << std::endl; 
  }
        
  if(frame_left.empty()) {
    std::cout << "frame_left empty" << std::endl; 
  }
        
  if(frame_right.empty()) {
    std::cout << "frame_right empty" << std::endl; 
  }
        
  if(frame_dms.empty()) {
    std::cout << "frame_dms empty" << std::endl; 
  }
  if(!outfile) {
    std::cout << "Unable to open otfile";
    exit(1); // terminate with error
  } 
  //save jpg  
              
  cv::imwrite(PATH_SAVE + std::to_string(1) + ".jpg", frame_front);
  cv::imwrite(PATH_SAVE + std::to_string(2) + ".jpg", frame_left);
  cv::imwrite(PATH_SAVE + std::to_string(3) + ".jpg", frame_right);
  cv::imwrite(PATH_SAVE + std::to_string(4) + ".jpg", frame_dms);   

  ros::spinOnce();
  std::string txt_content_per_line = "time:" + std::to_string(GetUnixTime()) +
  " ECU_id:" + ECU_id + 
  " stragy_ID:" + stragy_id +
  " stragy_TYPE:" + stragy_type +
  " VehicleSpeed:" + std::to_string(can::msgVehicleSpeed.data) +
  " SteeringAngle:" + std::to_string(can::msgSteeringAngle.data) +
  " AccelPedal:" + std::to_string(can::msgAccelPedalPosition.data) +
  " BrakePedal:" + std::to_string(can::msgBrakePedalPosition.data) +
  " Gear:" + std::to_string(can::msgGearPosition.data) +
  " TurnLLamp:" + std::to_string(can::msgTurnLLampStBool.data) +
  " TurnRLamp:" + std::to_string(can::msgTurnRLampStBool.data) +
  " ctrlSteeringAngle:" + std::to_string(can::msgctrlSteeringAngle.data);
          
  outfile << txt_content_per_line << std::endl;
  std::cout << txt_content_per_line << std::endl;

  sleep(1);  
  outfile.close();    
  capture_front.release();
  capture_left.release();
  capture_right.release();
  capture_dms.release();                

  std::string CMD2 = "sshpass -p 'XunXu_123' scp -r " + PATH_SAVE + " root@139.196.255.179:/root/shadow_data/"; 
  const char* cmd2 = CMD2.data();
  res = system(cmd2);
     
  sleep(2);     
}

void ShadowTrigger::ShadowLog(std_msgs::String& msgShadowLog, const Strategy& strategy) {
  float interval;

  if(strategy.weight < THRESHOLD) {
    trigger_log_.INFO("Begin DataBaseHandler.", true);
    DataBaseHandler(strategy,  strategy.duration.before_seconds, strategy.hz);

    interval = 1. / MaxFramesPerSec;
    while(sampler_size_ < MaxFramesPerSec * strategy.duration.after_seconds) {
      Sampler();
      std::this_thread::sleep_for(std::chrono::duration<double>(interval));
    }

    DataBaseHandler(strategy, strategy.duration.after_seconds, strategy.hz);
  }
  else {
     trigger_log_.INFO("Begin DataCloudHandler.", true);
    int res;
    int64_t time;
    std::string feature;
    std::string local_path, aliyun_path;
  
    time = shadow::GetUnixTime();
    feature = strategy.equipment_id + "type" + strategy.type +
            "id" + std::to_string(strategy.id) + 
            "time" + std::to_string(time) + "/";
    local_path = shadow::LocalSavePath + feature;
    aliyun_path = shadow::UploadAliyunPath + feature;

    upload_manager_.UpdateFile(local_path);
    res = system(("mkdir " + local_path).c_str());

    DataCloudHandler(strategy, strategy.duration.before_seconds, strategy.hz);

    interval = 1. / MaxFramesPerSec;
    while(sampler_size_ < MaxFramesPerSec * strategy.duration.after_seconds) {
      Sampler();
      std::this_thread::sleep_for(std::chrono::duration<double>(interval));
    }

    DataCloudHandler(strategy, strategy.duration.after_seconds, strategy.hz);
    msgShadowLog.data = strategy.equipment_id + "," + strategy.type + "," + 
        std::to_string(strategy.id) +","+ aliyun_path + "," + std::to_string(time);

    res = system(("sshpass -p 'XunXu_123' scp -r " + local_path + " root@139.196.255.179:/root/shadow_data/").c_str());
  }

}

void ShadowTrigger::DataBaseHandler(
    const Strategy& strategy, const int secs, const int hz) {
  if(sampler_size_ < MaxFramesPerSec) { return; }

  while(sampler_size_ > MaxFramesPerSec * secs || sampler_size_ % MaxFramesPerSec) {
    PopSampler();
  }

  int size = sampler_size_ / MaxFramesPerSec * hz;
  while(size) {
    int index = sampler_size_ / (size + 1);

    int i = 0;
    for(; i <= index; ++i) {
      if(index == i) {
        xlite_manager_.HandleData(DataManagerInterface::INSERT, 
            xlite_manager_.WrappedData(), strategy);
        --size;
      }

      PopSampler();
    }
  }
}

void ShadowTrigger::DataCloudHandler(
    const Strategy& strategy, const int secs, const int hz) {
  if(sampler_size_ < MaxFramesPerSec) { return; }

  while(sampler_size_ > MaxFramesPerSec * secs || sampler_size_ % MaxFramesPerSec) {
    PopSampler();
  }

  int size = sampler_size_ / MaxFramesPerSec * hz;
  while(size) {
    int index = sampler_size_ / (size + 1);

    int i = 0;
    for(; i <= index; ++i) {
      if(index == i) {
        upload_manager_.HandleData(DataManagerInterface::UPLOAD, 
            upload_manager_.WrappedData(), strategy);
        --size;
      }

      PopSampler();
    }
  }
}

void ShadowTrigger::UpdateTriggeredTimes(Strategy& sty, const int64_t& now) {
  if(0 == sty.frequency.last_time_h || 0 == sty.frequency.last_time_24h) {
    sty.frequency.last_time_h = now;
    sty.frequency.frequency_h_times = 1;
    sty.frequency.last_time_24h = now;
    sty.frequency.frequency_24h_times = 1;
    return;
  }

  ++sty.frequency.frequency_h_times;
  ++sty.frequency.frequency_24h_times;
}

bool ShadowTrigger::SolidifyStrategyFromCloudCMD(const int strategy_id, const std::vector<int>& judge_ids,
    const std::vector<CustomizedInfo>& customied_infos, const std::vector<enum Logic>& logics) {
  if(judge_ids.size() != customied_infos.size() || 
      judge_ids.size() != logics.size() + 1) { return false; }
  
  for(int i = 0; i < judge_ids.size(); ++i) {
    if(judge_ids.size() - 1 == i) {
      return xlite_manager_.InsertStrategy(strategy_id, judge_ids[i], customied_infos[i], END);
    }
    if(!xlite_manager_.InsertStrategy(
        strategy_id, judge_ids[i], customied_infos[i], logics[i])) { return false; };
  }

  return true;
}

void ShadowTrigger::LoadStrategy() {
  int id;
  int strategy_id;
  int judge_id;
  CustomizedInfo info;
  enum Logic logic;

  id = 1;
  while(xlite_manager_.SelectStrategy(id, strategy_id, judge_id, info, logic)) {
    strategy::mapper[strategy_id].id = strategy_id;
    strategy::mapper[strategy_id].judges.emplace_back(judge_id);
    if(END != logic) {
      strategy::mapper[strategy_id].combo.emplace_back(logic);
    }
    strategy::judge.AddJudge(info, judge_id);
    ++id;
  }

  trigger_log_.INFO("Loaded " + std::to_string(strategy::mapper.size()) + " strategies.", true);
}

} // !namespace shadow


