#ifndef SHADOW_UTILS_H
#define SHADOW_UTILS_H

#define _atoi64(val)     strtoll(val, NULL, 10)  
#define FEEL_FRAME

#include "std_msgs/String.h"

#include <chrono>
#include <fstream>

namespace shadow {

typedef struct {
  int year;
  int month;
  int day;
  int hour;
  int minute;
  int second;
} TimeStamp;

int64_t GetUnixTime();

void GetTimeStamp(TimeStamp& ts);

class TriggerLog {
 public:
  TriggerLog();
  ~TriggerLog();

  TriggerLog(const TriggerLog&) = delete;
  TriggerLog& operator=(const TriggerLog&) = delete;

  void INFO(const std::string& s, const bool is_print = false);
  void WARN(const std::string& s, const bool is_print = true);
  void ERROR(const std::string& s, const bool is_print = true);

 private:
  void PrintDate(std::string& date);
  void WriteLog(const std::string& line, const bool is_print);

  std::ofstream file_;
  TimeStamp time_stamp_;
  std::string info_, warn_, error_;
};

} // !namespace shadow

#endif // !SHADOW_UTILS_H

