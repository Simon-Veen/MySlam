#ifndef SHADOW_GLOBAL_H
#define SHADOW_GLOBAL_H 

#include "can_signal.h"
#include "adas_signal.h"
#include "perception_signal.h"
#include "strategy_signal.h"
#include "trigger_signal.h"


#endif // !SHADOW_GLOBAL_H
