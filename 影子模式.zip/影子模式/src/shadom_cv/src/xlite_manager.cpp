#include "xlite_manager.h"
#include "trigger_signal.h"
#include "shadow_constant.h"

XliteManager::XliteManager() : DataManagerInterface() {
  OpenDateBase(shadow::DataBasePath);

  CreateTable(shadow::SignalsTable);
  CreateTable(shadow::FramesTable);
  CreateTable(shadow::StratrgiesTabel);
}

XliteManager::~XliteManager() {}

bool XliteManager::HandleData(
    enum HandleType handle_type, const Data& data, const Strategy& strategy) {
  switch(handle_type) {
    case INSERT:
      return Insert(data, strategy);
    default:
      return false;
  }

  return false;
}

Data XliteManager::WrappedData() {
  Data data;

  data.flash_capture = &shadow::buffer::flashCapturesQueue.front();
  #ifdef FEEL_FRAME
    cv::imencode(".jpg", shadow::buffer::framesQueue.front(), data.frame);
  #endif

  return data;
}

bool XliteManager::InsertStrategy(const int strategy_id, const int judge_id, 
    const shadow::CustomizedInfo& customied_info, const enum Logic logic) {
  OpenDateBase("shadow.db");

  int rc = sqlite3_prepare_v2(db, shadow::InsertStratrgyQuery, -1, &stmt, NULL);
  if(rc != SQLITE_OK) {
    std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  sqlite3_bind_int(stmt, 1, strategy_id);
  sqlite3_bind_int(stmt, 2, judge_id);
  sqlite3_bind_text(stmt, 3, customied_info.signal.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_int(stmt, 4, customied_info.comparator);
  sqlite3_bind_double(stmt, 5, customied_info.base);
  sqlite3_bind_int(stmt, 6, logic);

  rc = sqlite3_step(stmt);
  if(rc != SQLITE_DONE) {
    std::cerr << "Failed to execute statement: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  sqlite3_finalize(stmt);
  sqlite3_close(db);

  return true;
}

bool XliteManager::SelectStrategy(const int id, int& strategy_id, int& judge_id,
    shadow::CustomizedInfo& customied_info, enum Logic& logic) {
  OpenDateBase("shadow.db");
  
  std::string query = std::string(shadow::SelectStratrgyQuery) + std::to_string(id);

  int rc = sqlite3_prepare_v2(db, query.c_str(), -1, &stmt, NULL);
  if(rc != SQLITE_OK) {
    std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  bool success = false;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    strategy_id = sqlite3_column_int(stmt, 1);
    judge_id = sqlite3_column_int(stmt, 2);
    std::string str(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3)));
    customied_info.signal = str;
    customied_info.comparator = static_cast<enum shadow::Comparator>(sqlite3_column_int(stmt, 4));
    customied_info.base = sqlite3_column_int(stmt, 5);
    logic = static_cast<enum Logic>(sqlite3_column_int(stmt, 6));
    success = true;
  }

  sqlite3_finalize(stmt);
  sqlite3_close(db);

  return success;
}

bool XliteManager::OpenDateBase(const char* path) {
  int rc = sqlite3_open(path, &db);
  if(rc != SQLITE_OK) {
    std::cerr << "Failed to open database: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_close(db);
    return false;
  }
  return true;
}

bool XliteManager::CreateTable(const char* query) {
  int rc = sqlite3_exec(db, query, NULL, NULL, &errMsg);
  if(rc != SQLITE_OK) {
    std::cerr << "Failed to create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
    sqlite3_close(db);
    return false;
  }
  return true;
}

bool XliteManager::Insert(const Data& data, const Strategy& strategy) {
  if(!InsertSignal(data, strategy)) { return false; }
  #ifdef FEEL_FRAME
    if(!InsertFrame(data, strategy)) { return false; }
  #endif

  return true;
}

bool XliteManager::InsertSignal(const Data& data, const Strategy& strategy) {
  OpenDateBase("shadow.db");

  int rc = sqlite3_prepare_v2(db, shadow::InsertSignalQuery, -1, &stmt, NULL);
  if(rc != SQLITE_OK) {
    std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  sqlite3_bind_int64(stmt, 1, data.flash_capture->timestamp);
  sqlite3_bind_text(stmt, 2, strategy.equipment_id.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_int(stmt, 3, strategy.id);
  sqlite3_bind_text(stmt, 4, strategy.type.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_double(stmt, 5, data.flash_capture->msgVehicleSpeed.data);
  sqlite3_bind_double(stmt, 6, data.flash_capture->msgSteeringAngle.data);
  sqlite3_bind_double(stmt, 7, data.flash_capture->msgAccelPedalPosition.data);
  sqlite3_bind_double(stmt, 8, data.flash_capture->msgBrakePedalPosition.data);
  sqlite3_bind_int(stmt, 9, data.flash_capture->msgGearPosition.data);
  sqlite3_bind_int(stmt, 10, data.flash_capture->msgTurnLLampStBool.data? 1 : 0);
  sqlite3_bind_int(stmt, 11, data.flash_capture->msgTurnRLampStBool.data? 1 : 0);

  rc = sqlite3_step(stmt);
  if(rc != SQLITE_DONE) {
    std::cerr << "Failed to execute statement: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  sqlite3_finalize(stmt);
  sqlite3_close(db);

  return true;
}

bool XliteManager::InsertFrame(const Data& data, const Strategy& strategy) {
  OpenDateBase("shadow.db");

  int rc = sqlite3_prepare_v2(db, shadow::InsertFrameQuery, -1, &stmt, NULL);
  if(rc != SQLITE_OK) {
    std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }
  
  rc = sqlite3_bind_blob(stmt, 1, data.frame.data(), data.frame.size(), SQLITE_STATIC);
  if(rc != SQLITE_OK) {
    std::cerr << "Can't bind blob: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  rc = sqlite3_step(stmt);
  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert image: " << sqlite3_errmsg(db) << std::endl;
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return false;
  }

  sqlite3_finalize(stmt);
  sqlite3_close(db);

  return true;
}
