#ifndef TRIGGER_SIGNAL
#define TRIGGER_SIGNAL

#include "shadow_trigger.h"
#include <deque>

namespace shadow {

namespace buffer {

extern std::deque<FlashCapture> flashCapturesQueue;
extern std::deque<cv::Mat> framesQueue;

} // !buff

namespace trigger {

extern ShadowTrigger tgr;

} // !trigger

} // !shadow

#endif // !TRIGGER_SIGNAL
