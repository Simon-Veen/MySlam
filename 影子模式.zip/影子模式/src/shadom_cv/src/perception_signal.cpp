#include "perception_signal.h"

namespace shadow {

namespace perception {

std_msgs::Bool msgHumdensityBool; // 感知行人密度
std_msgs::Bool msgConeBool; // 感知锥桶
std_msgs::Bool msgIlluminationBool; // 感知光照
std_msgs::Bool msgTrafficLightBool; // 红绿灯检测
std_msgs::Bool msgSpeedlimitBool; // 限速牌检测
std_msgs::Int8 msgSceneDect; // 场景识别
std_msgs::Bool msgDectweatherBool; // 感知天气
std_msgs::Bool msgtrafficsignsBool; // 感知交通牌 
std_msgs::Bool msgHumancategoryBool; // 感知行人类别
std_msgs::Bool msgVehiclecategoryBool; // 感知车辆类别（特种车辆）
} // !namespace perception

}
