#ifndef XLITE_MANAGER_H
#define XLITE_MANAGER_H

#include "data_manager_interface.h"
#include "shadow_utils.h"
#include "strategy_judges_manager.h"

#include <sqlite3.h>
#include <iostream>

class XliteManager : public DataManagerInterface {
 public:
  XliteManager();
  ~XliteManager();

  XliteManager(const XliteManager&) = delete;
  XliteManager& operator=(const XliteManager&) = delete;

  bool HandleData(enum HandleType, const Data&, const Strategy&) override;
  Data WrappedData() override;

  bool InsertStrategy(const int strategy_id, const int judge_id,
      const shadow::CustomizedInfo& customied_info, const enum Logic logic);
  
  bool SelectStrategy(const int id, int& strategy_id, int& judge_id,
      shadow::CustomizedInfo& customied_info, enum Logic& logic);

 private:
  bool OpenDateBase(const char* path);
  bool CreateTable(const char* query);
  bool Insert(const Data& data, const Strategy& strategy);
  bool InsertSignal(const Data& data, const Strategy& strategy);
  bool InsertFrame(const Data& data, const Strategy& strategy);

  sqlite3* db;
  sqlite3_stmt* stmt;
  char* errMsg;
};

#endif // ! XLITE_MANAGER_H
