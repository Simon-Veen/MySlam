#ifndef SHADOW_CONSTANT_H
#define SHADOW_CONSTANT_H

namespace shadow {

constexpr int MaxNestedJudgeNum = 41;

constexpr int MaxFramesPerSec = 30;
constexpr int MaxBufferSize = 30;

constexpr char DataBasePath[] = "shadow.db";

constexpr char SignalsTable[] = "CREATE TABLE IF NOT EXISTS SIGNALS " \
                                "(ID INTEGER PRIMARY KEY, " \
                                "TIME                  INTEGER, " \
                                "ECU_ID                TEXT, " \
                                "STRATEGY_ID           INTEGER, " \
                                "STRATEGY_TYPE         TEXT, " \
                                "VEHICLE_SPEED         REAL, " \
                                "STEERING_ANGLE        REAL, " \
                                "ACCEL_PEDAL_POSITION  REAL, " \
                                "BRAKE_PEDAL_POSITION  REAL, " \
                                "GEAR_POSITION         INTEGER, " \
                                "TURN_LLAMP_BOOL       INTEGER, " \
                                "TURN_RLAMP_BOOL       INTEGER)";

constexpr char InsertSignalQuery[] = "INSERT INTO SIGNALS " \
                                     "(TIME, ECU_ID, STRATEGY_ID, STRATEGY_TYPE, " \
                                     "VEHICLE_SPEED, STEERING_ANGLE, ACCEL_PEDAL_POSITION, BRAKE_PEDAL_POSITION, " \
                                     "GEAR_POSITION, TURN_LLAMP_BOOL, TURN_RLAMP_BOOL) " \
                                     "VALUES (?, ?, ?, ?, " \
                                             "?, ?, ?, ?, " \
                                             "?, ?, ?)";

constexpr char FramesTable[] = "CREATE TABLE IF NOT EXISTS FRAMES " \
                               "(ID INTEGER PRIMARY KEY, " \
                               "DATA                BLOB)";

constexpr char InsertFrameQuery[] = "INSERT INTO FRAMES " \
                                    "(data) " \
                                    "VALUES (?)";

constexpr char StratrgiesTabel[] = "CREATE TABLE IF NOT EXISTS STRATRGIES " \
                                   "(ID INTEGER PRIMARY KEY, " \
                                   "STRATEGY_ID           INTEGER, " \
                                   "JUDGE_ID              INTEGER, " \
                                   "SIGNAL                TEXT, " \
                                   "COMPARATOR            INTEGER, " \
                                   "BASE                  REAL, "\
                                   "LOGIC                 INTEGER)";
                            
constexpr char InsertStratrgyQuery[] = "INSERT INTO STRATRGIES " \
                                       "(STRATEGY_ID, JUDGE_ID, SIGNAL, COMPARATOR, " \
                                       "BASE, LOGIC) " \
                                       "VALUES (?, ?, ?, ?, " \
                                               "?, ?)";

constexpr char SelectStratrgyQuery[] = "SELECT * FROM STRATRGIES WHERE ID = ";

constexpr char LocalSavePath[] = "/home/nvidia/shadow_data/";
constexpr char UploadAliyunPath[] = "/root/shadow_data/";

}

#endif // !SHADOW_CONSTANT_H
