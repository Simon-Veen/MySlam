#include "can_signal.h"

namespace shadow {

namespace can {

can_msgs::Frame CANsub_msgs_ID_0X350; //848
can_msgs::Frame CANsub_msgs_ID_0X351; //849
can_msgs::Frame CANsub_msgs_ID_0X352; //850
can_msgs::Frame CANsub_msgs_ID_0X359; //857
can_msgs::Frame CANsub_msgs_ID_0X370; //880
can_msgs::Frame CANsub_msgs_ID_0X360; //864

int64_t prev_time_0X351, current_time_0X351; // 计算方向盘转速
std_msgs::Float32 prev_msgSteeringAngle; 
std_msgs::Float32 msgSteeringSpeed;

int64_t prev_time_0X350, current_time_0X350; // 计算纵向加速度
std_msgs::Float32 prev_msgVehicleSpeed; 
std_msgs::Float32 msgVehicleAccel; 

int64_t prev_time_0X360, current_time_0X360; // 判断连续两次开启远光灯
std_msgs::Bool prev_msgHeadLampBool;
std_msgs::Bool msgDblHeadLampBool;

std_msgs::Bool msgHornBool; // 喇叭控制
std_msgs::Bool msgDblFlashLampBool; // 双闪灯开关
std_msgs::Bool msgHeadLampBool; // 前大灯控制

//task1:get car message
std_msgs::Float32 msgVehicleSpeed; // 车速
std_msgs::Float32 msgSteeringAngle; // 方向盘转角状态
std_msgs::Float32 msgAccelPedalPosition; // 油门行程状态
std_msgs::Int8 msgGearPosition; // 档位状态
//std_msgs::Float32 msgYawRate;
//std_msgs::Float32 msgLongitAcce;
//std_msgs::Float32 msgLateralAcce;
std_msgs::Int8 msgDriveMode;

//update for car_jiyu 20220107
std_msgs::Float32 msgBrakePedalPosition; // 制动行程状
std_msgs::Bool msgTurnRLampStBool; // 右转灯开启状态
std_msgs::Bool msgTurnLLampStBool; // 左转灯开启状态
std_msgs::Bool msgmanAccelPedalPositionBool; // 人工干预油门踏板
std_msgs::Bool msgmanBrakePedalPositionBool; // 人工干预制动踏板
std_msgs::Bool msgmanSteeringAngleBool; // 人工干预方向盘状态
std_msgs::Bool msgmanGearPositionBool; // 人工干预档位旋钮
std_msgs::Bool msgmanDriveModeBool; // 人工退智驾按钮
std_msgs::Bool msgCANmsgsStBool;
std_msgs::Bool msgMQTTmsgsStBool;

//update for car_jiyu 20230201
std_msgs::Bool msgShakeLStBool; // 纵向握手状态
std_msgs::Bool msgShakeHStBool; // 横向握手状态
std_msgs::Bool msgBrakeModeStBool; // 制动模式状态

//update for car_jiyu 20230116
//limSpdSt   //0x352
std_msgs::Float32 msgLimSpdSt; // 限制的速度反馈值

//task2:ctrl car 
std_msgs::Int8 msgctrlDriveMode;
std_msgs::Float32 msgctrlAccelPedalPosition;
std_msgs::Float32 msgctrlBrakePedalPosition;
std_msgs::Float32 msgctrlSteeringAngle;
std_msgs::Float32 msgdeltctrlAccelPedalPosition;
std_msgs::Float32 msgdeltctrlBrakePedalPosition;
std_msgs::Float32 msgdeltctrlSteeringAngle;
std_msgs::Int8 msgctrlGearPosition;
//update forjiyu 20230111
std_msgs::Bool msgctrlTurnRLamp;
std_msgs::Bool msgctrlTurnLLamp;
std_msgs::Bool msgctrlDlbFlashLamp;
std_msgs::Bool msgctrlHorn;
//update forjiyu 20230111
std_msgs::Float32 msgctrlLimSpd;
//update forjiyu 20230116
std_msgs::Bool msgctrlEmgStop;// jiyu empty
std_msgs::Int8 msgDriveModeReq;//Drive mode result to AD ECU  shakeReq 0x2

std_msgs::Int8 msgEPSStrFltCode; // EPS握手故障
std_msgs::Int8 msgEPSInhibitCode; // EPS无法响应的原因
std_msgs::Bool msgEHBUSplyLowLv2Bool; // 供电电压过低故障
std_msgs::Bool msgEHBUSplyLowLv1Bool; // 供电电压过低异常
std_msgs::Bool msgEHBUSplyHighLv2Bool; // 供电电压过高故障
std_msgs::Bool msgEHBUSplyHighLv1Bool; // 供电电压过高异常
std_msgs::Bool msgEHBPwrSwtFltBool; // 功率开关故障
std_msgs::Bool msgEHBPwrDrvrFltBool; // 预驱故障
std_msgs::Bool msgEHBPSnsrFltBool; // 液压力传感器故障
std_msgs::Bool msgEHBPFolwFltLv2Bool; // EHB液压力跟随严重异常
std_msgs::Bool msgEHBPFolwFltLv1Bool; // EHB液压力跟随轻微异常
std_msgs::Bool msgEHBPedlSnsrFltSingleBool; // 踏板位移传感器单路故障
std_msgs::Bool msgEHBPedlSnsrFltBothBool; // 踏板位移传感器双路故障
std_msgs::Bool msgEHBPCtrlVibLv2Bool; // EHB液压力严重震荡
std_msgs::Bool msgEHBPCtrlVibLv1Bool; // EHB液压力轻微震荡
std_msgs::Bool msgEHBOverTempWarnBool; // 控制器温度过高
std_msgs::Bool msgEHBOverIFltBool; // EHB过流故障
std_msgs::Bool msgEHBNTCFltLv2Bool; // 温度传感器完全故障
std_msgs::Bool msgEHBNTCFltLv1Bool; // 温度传感器部分故障
std_msgs::Bool msgEHBMotPosnFltBool; // EHB电机位置失效
std_msgs::Bool msgEHBLoadMismatchFltBool; // 负载失配故障
std_msgs::Bool msgEHBISnsrFltBool; // 电流传感器故障
std_msgs::Bool msgEHBCANBusOffBool; // CAN通信故障
std_msgs::Bool msgEHBBrkReqWarnBool; // 制动指令异常

//
std_msgs::Float32 msgLongacc; // 纵向加速度
std_msgs::Float32 msgLateracc; // 横向加速度
std_msgs::Int8 TirePressure; // 胎压
std_msgs::Bool FaultSignalBool; // 故障信号
std_msgs::Float32 msgIMUdata; // IMU姿态传感器
std_msgs::Float32 msgGPSdata;// GPS数据定位
std_msgs::Int8 msgTimedata; //时间

} // !namespace can

} // !shadow
