#ifndef DATA_MANAGER_INTERFACE_H 
#define DATA_MANAGER_INTERFACE_H

#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Int8.h"
#include "std_msgs/Bool.h"

// OpenCV2标准头文件
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

// DATA

#pragma region 

typedef struct {
  int64_t timestamp;
  std_msgs::Float32 msgVehicleSpeed;
  std_msgs::Float32 msgSteeringAngle;
  std_msgs::Float32 msgAccelPedalPosition;
  std_msgs::Float32 msgBrakePedalPosition;
  std_msgs::Int8 msgGearPosition;
  std_msgs::Bool msgTurnLLampStBool;
  std_msgs::Bool msgTurnRLampStBool;
  std_msgs::Float32 msgctrlSteeringAngle;
} FlashCapture;

typedef struct FREQUENCY {
  int frequency_h_times;
  int frequency_24h_times;
  int frequency_h_times_limit;
  int frequency_24h_times_limit;

  int64_t last_time_h;
  int64_t last_time_24h;

  inline bool valid(const int64_t now) {
    if(0 != last_time_h && 0 != last_time_24h) {
      if(now - last_time_h >= 3600000) { 
        frequency_h_times = 0; 
        last_time_h = now;
      }
      if(now - last_time_24h >= 3600000 * 24) { 
        frequency_24h_times = 0; 
        last_time_24h = now;
      }
    }

    return (frequency_h_times < frequency_h_times_limit &&
      frequency_24h_times < frequency_24h_times_limit);
  }
} Frequency;

typedef struct _Duration {
  int64_t time_start;
  int64_t time_stop;
  int before_seconds;
  int after_seconds;

  inline bool valid(const int64_t now) {
    return (time_start < now && time_stop > now);
  }
} Duration;

enum Logic {
  AND,
  OR,
  END,
};

typedef struct {
  int id;
  std::vector<enum Logic> combo;
  std:: string equipment_id;
  std::string type;
  std::vector<int> judges;
  float weight;
  int hz;
  Duration duration;
  Frequency frequency;
  bool is_actived;
} Strategy;

#pragma endregion

typedef struct {
  const FlashCapture* flash_capture;
  std::vector<u_char> frame;
  cv::Mat* image;
} Data;

class DataManagerInterface {
 public:
  DataManagerInterface() {}

  DataManagerInterface(const DataManagerInterface&) = delete;
  DataManagerInterface& operator=(const DataManagerInterface&) = delete;

  enum HandleType {
    INSERT = 1,
    DELTE,
    READ,
    UPDATE,
    UPLOAD,
  };

  virtual bool HandleData(enum HandleType,
      const Data&, const Strategy&) = 0;

  virtual Data WrappedData() = 0;
};

#endif // ! DATA_MANAGER_INTERFACE_H
