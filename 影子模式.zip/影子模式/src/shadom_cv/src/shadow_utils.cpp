#include "shadow_utils.h"
#include "shadow_global.h"
#include "shadow_trigger.h"
#include"ros/ros.h"

namespace shadow {

int64_t GetUnixTime() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
}

void GetTimeStamp(TimeStamp& ts) {
  std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
  std::time_t t = std::chrono::system_clock::to_time_t(now);   
  std::tm* now_tm = std::localtime(&t);

  ts.year = now_tm->tm_year + 1900;
  ts.month = now_tm->tm_mon + 1;
  ts.day = now_tm->tm_mday;
  ts.hour = now_tm->tm_hour;
  ts.minute = now_tm->tm_min;
  ts.second = now_tm->tm_sec;
}

TriggerLog::TriggerLog() {
  GetTimeStamp(time_stamp_);
  
  std::string path;
  path += "trigger_log_";
  path += std::to_string(time_stamp_.year) + "_";
  if(time_stamp_.month < 10) { path += "0"; }
  path += std::to_string(time_stamp_.month) + "_";
  if(time_stamp_.day < 10) { path += "0"; }
  path += std::to_string(time_stamp_.day) + "_";
  if(time_stamp_.hour < 10) { path += "0"; }
  path += std::to_string(time_stamp_.hour) + "_";
  if(time_stamp_.minute < 10) { path += "0"; }
  path += std::to_string(time_stamp_.minute) + "_";
  if(time_stamp_.second < 10) { path += "0"; }
  path += std::to_string(time_stamp_.second);


  file_.open(path,
      std::ios::in | std::ios::out | std::ios::app);
}

TriggerLog::~TriggerLog() {
  file_.close();
}

void TriggerLog::INFO(const std::string& s, const bool is_print) {
  std::string date;

  PrintDate(date);
  info_ = date + " INFO " + std::move(s);
  WriteLog(info_, is_print);
}

void TriggerLog::WARN(const std::string& s, const bool is_print) {
  std::string date;

  PrintDate(date);
  warn_ = date + " WARN " + std::move(s);
  WriteLog(warn_, is_print);
}

void TriggerLog::ERROR(const std::string& s, const bool is_print) {
  std::string date;

  PrintDate(date);
  error_ = date + " ERROR " + std::move(s);
  WriteLog(error_, is_print);
}


void TriggerLog::PrintDate(std::string& date) {
  GetTimeStamp(time_stamp_);

  date += "[ ";
  date += std::to_string(time_stamp_.year) + "/";
  if(time_stamp_.month < 10) { date += "0"; }
  date += std::to_string(time_stamp_.month) + "/";
  if(time_stamp_.day < 10) { date += "0"; }
  date += std::to_string(time_stamp_.day) + " ";
  if(time_stamp_.hour < 10) { date += "0"; }
  date += std::to_string(time_stamp_.hour) + ":";
  if(time_stamp_.minute < 10) { date += "0"; }
  date += std::to_string(time_stamp_.minute) + ":";
  if(time_stamp_.second < 10) { date += "0"; }
  date += std::to_string(time_stamp_.second);
  date += " ]";
}

void TriggerLog::WriteLog(const std::string& line, const bool is_print) {
  if(is_print) { std::cout << line << std::endl; }
  
  file_ << line << std::endl;
}

} // !namespace shadow
