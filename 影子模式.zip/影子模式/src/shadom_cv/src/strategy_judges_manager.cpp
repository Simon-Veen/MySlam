#include "strategy_judges_manager.h"
#include "shadow_global.h"
#include "shadow_constant.h"

namespace shadow {

StrategyJudgeManager::StrategyJudgeManager() 
    : customized_judge_size_(MaxNestedJudgeNum) {
  // Judge Init
  #pragma region 
  trigger_judge_list_[1] = &strategy_id1_trigger_judge;
  trigger_judge_list_[2] = &strategy_id2_trigger_judge;
  trigger_judge_list_[3] = &strategy_id3_trigger_judge;
  trigger_judge_list_[4] = &strategy_id4_trigger_judge;
  trigger_judge_list_[5] = &strategy_id5_trigger_judge;
  trigger_judge_list_[6] = &strategy_id6_trigger_judge;
  trigger_judge_list_[7] = &strategy_id7_trigger_judge;
  trigger_judge_list_[8] = &strategy_id8_trigger_judge;
  trigger_judge_list_[9] = &strategy_id9_trigger_judge;
  trigger_judge_list_[10] = &strategy_id10_trigger_judge;
  trigger_judge_list_[11] = &strategy_id11_trigger_judge;
  trigger_judge_list_[12] = &strategy_id12_trigger_judge;
  trigger_judge_list_[13] = &strategy_id13_trigger_judge;
  trigger_judge_list_[14] = &strategy_id14_trigger_judge;
  trigger_judge_list_[15] = &strategy_id15_trigger_judge;
  trigger_judge_list_[16] = &strategy_id16_trigger_judge;
  trigger_judge_list_[17] = &strategy_id17_trigger_judge;
  trigger_judge_list_[18] = &strategy_id18_trigger_judge;
  trigger_judge_list_[19] = &strategy_id19_trigger_judge;
  trigger_judge_list_[20] = &strategy_id20_trigger_judge;
  trigger_judge_list_[21] = &strategy_id21_trigger_judge;
  trigger_judge_list_[22] = &strategy_id22_trigger_judge;
  trigger_judge_list_[23] = &strategy_id23_trigger_judge;
  trigger_judge_list_[24] = &strategy_id24_trigger_judge;
  trigger_judge_list_[25] = &strategy_id25_trigger_judge;
  trigger_judge_list_[26] = &strategy_id26_trigger_judge;
  trigger_judge_list_[27] = &strategy_id27_trigger_judge;
  trigger_judge_list_[28] = &strategy_id28_trigger_judge;
  trigger_judge_list_[29] = &strategy_id29_trigger_judge;
  trigger_judge_list_[30] = &strategy_id30_trigger_judge;
  trigger_judge_list_[31] = &strategy_id31_trigger_judge;
  trigger_judge_list_[32] = &strategy_id32_trigger_judge;
  trigger_judge_list_[33] = &strategy_id33_trigger_judge;
  trigger_judge_list_[34] = &strategy_id34_trigger_judge;
  trigger_judge_list_[35] = &strategy_id35_trigger_judge;
  trigger_judge_list_[36] = &strategy_id36_trigger_judge;
  trigger_judge_list_[37] = &strategy_id37_trigger_judge;
  trigger_judge_list_[38] = &strategy_id38_trigger_judge;
  trigger_judge_list_[39] = &strategy_id39_trigger_judge;
  trigger_judge_list_[40] = &strategy_id40_trigger_judge;
  trigger_judge_list_[41] = &strategy_id41_trigger_judge;
  #pragma endregion
}

StrategyJudgeManager::~StrategyJudgeManager() {

}

std::vector<int> StrategyJudgeManager::AddJudge(
    const std::vector<CustomizedInfo>& info) {
  std::vector<int> judges;
  int judge_id;

  judge_id = customized_judge_size_;
  for(const auto& it : info) {
    while(customized_judge_list_.count(++judge_id));

    customized_judge_list_[judge_id] = it;
    judges.emplace_back(judge_id);
    ++customized_judge_size_;
  }
  return judges;
}

void StrategyJudgeManager::AddJudge(const CustomizedInfo& info, const int judge_id) {
  customized_judge_list_[judge_id] = info;
  ++customized_judge_size_;
}

bool StrategyJudgeManager::Result(const int id) {
  if(id <= MaxNestedJudgeNum) {
    return trigger_judge_list_[id]();
  }
  else {
    return ConfirmSignal(customized_judge_list_[id]);
  }
  return false;
}

template<typename T>
bool StrategyJudgeManager::CustomizedJudge(
    const T& signal, const CustomizedInfo& info) {
  switch(info.comparator) {
    case GREATER:
      return signal > info.base;
    case GORE:
      return signal >= info.base;
    case LESS:
      return signal < info.base;
    case LORE:
      return signal <= info.base;
    case EQUAL:
      return signal == info.base;
    default:
      return false; 
  }
  return false;  
}



bool StrategyJudgeManager::ConfirmSignal(const CustomizedInfo& info) {
  #pragma region // Customized Judge

  if("msgVehicleSpeed" == info.signal) {
    return CustomizedJudge<float>(can::msgVehicleSpeed.data, info);
  }
  else if("msgHornBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgHornBool.data, info);
  }
  else if("msgDblFlashLampBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgDblFlashLampBool.data, info);
  }
  else if("msgHeadLampBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgHeadLampBool.data, info);
  }
  else if("msgEPSInhibitCode" == info.signal) {
    return CustomizedJudge<int>(can::msgEPSInhibitCode.data, info);
  }
  else if("msgTurnRLampStBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgTurnRLampStBool.data, info);
  }
  else if("msgTurnLLampStBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgTurnLLampStBool.data, info);
  }
  else if("msgmanGearPositionBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgmanGearPositionBool.data, info);
  }
  else if("msgmanDriveModeBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgmanDriveModeBool.data, info);
  }
  else if("msgmanSteeringAngleBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgmanSteeringAngleBool.data, info);
  }
  else if("msgmanBrakePedalPositionBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgmanBrakePedalPositionBool.data, info);
  }
  else if("msgmanAccelPedalPositionBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgmanAccelPedalPositionBool.data, info);
  }
  else if("msgBrakePedalPosition" == info.signal) {
    return CustomizedJudge<float>(can::msgBrakePedalPosition.data, info);
  }
  else if("msgSteeringAngle" == info.signal) {
    return CustomizedJudge<float>(can::msgSteeringAngle.data, info);
  }
  else if("msgAccelPedalPosition" == info.signal) {
    return CustomizedJudge<float>(can::msgAccelPedalPosition.data, info);
  }
  else if("msgShakeHStBool" == info.signal) {
    return CustomizedJudge<bool>(can::msgShakeHStBool.data, info);
  }
  else if("msgLimSpdSt" == info.signal) {
    return CustomizedJudge<float>(can::msgLimSpdSt.data, info);
  }

  return false;

  #pragma endregion
}

// Judge Definition
#pragma region 

bool strategy_id1_trigger_judge() {
  return false;
}

bool strategy_id2_trigger_judge() {
  return can::msgBrakePedalPosition.data > 80.0;
}

bool strategy_id3_trigger_judge(){

  return can::msgTurnLLampStBool.data;
}

bool strategy_id4_trigger_judge() {
  
  return can::msgTurnRLampStBool.data;
}

bool strategy_id5_trigger_judge() {
  return can::msgGearPosition.data == 2;
}

bool strategy_id6_trigger_judge() {
  return can::msgSteeringAngle.data > 360.0;
}

bool strategy_id7_trigger_judge() {
  return can::msgSteeringAngle.data < -360.0;
}

bool strategy_id8_trigger_judge() {
  return perception::msgSceneDect.data == 1;
}

bool strategy_id9_trigger_judge() {
  return perception::msgSceneDect.data == 2;
}

bool strategy_id10_trigger_judge() {
  return perception::msgConeBool.data;
}

bool strategy_id11_trigger_judge() {
  return perception::msgHumdensityBool.data;
}

bool strategy_id12_trigger_judge() {
  return perception::msgIlluminationBool.data;
}

bool strategy_id13_trigger_judge() {
  return fabs(can::msgSteeringAngle.data) > 90 &&
      fabs(can::msgSteeringSpeed.data) > 180;
}

bool strategy_id14_trigger_judge() {
  return can::msgHornBool.data;
}

bool strategy_id15_trigger_judge() {
  return can::msgDblFlashLampBool.data;
}

bool strategy_id16_trigger_judge() {
  return can::msgDblHeadLampBool.data;
}

bool strategy_id17_trigger_judge() {
  return can::msgVehicleAccel.data > 15.0;
}

bool strategy_id18_trigger_judge() {
  return can::msgLateracc.data > 10.0;
}

bool strategy_id19_trigger_judge() {
  return can::msgLongacc.data > 50;
}

bool strategy_id20_trigger_judge() {
  return can::TirePressure.data < 1.2;
}

bool strategy_id21_trigger_judge() {
  return can::FaultSignalBool.data == 1;
}

bool strategy_id22_trigger_judge() {
  return can::msgIMUdata.data < -10;
}

bool strategy_id23_trigger_judge() {
  return can::msgIMUdata.data > 10;
}

bool strategy_id24_trigger_judge() {
  return can::msgGPSdata.data == 0;
}

bool strategy_id25_trigger_judge() {
  return can::msgTimedata.data == 10;
}

bool strategy_id26_trigger_judge() {
  return perception::msgTrafficLightBool.data;
}

bool strategy_id27_trigger_judge() {
  return perception::msgSpeedlimitBool.data == 1;  //场景
}

bool strategy_id28_trigger_judge() {
  return perception::msgSceneDect.data == 1;
}

bool strategy_id29_trigger_judge() {
  return perception::msgTrafficLightBool.data == 1;
}

bool strategy_id30_trigger_judge() {
  return perception::msgSpeedlimitBool.data == 1;
}

bool strategy_id31_trigger_judge() {
  return perception::msgDectweatherBool.data == 1;
}

bool strategy_id32_trigger_judge() {
  return perception::msgtrafficsignsBool.data == 1;
}

bool strategy_id33_trigger_judge() {
  return perception::msgHumancategoryBool.data == 1;
}

bool strategy_id34_trigger_judge() {
  return perception::msgVehiclecategoryBool.data == 1;
}

bool strategy_id35_trigger_judge() {
  return adas::adasmsgFCWwarnBool.data == 1;
}

bool strategy_id36_trigger_judge() {
  return adas::adasmsgAEBTriggerBool.data == 1;
}

bool strategy_id37_trigger_judge() {
  return adas::adasmsgLDWTriggerBool.data == 1;
}

bool strategy_id38_trigger_judge() {
  return adas::adasmsgBSDWarnBool.data == 1;
}

bool strategy_id39_trigger_judge() {
  return adas::adasmsgTogglelanechangeBool.data == 1;
}

bool strategy_id40_trigger_judge() {
  return adas::adasmsgOvertakingBool.data == 1;
}

bool strategy_id41_trigger_judge() {
  return adas::adasmsgAPATriggerBool.data == 1;
}

#pragma endregion

} // !shadow
