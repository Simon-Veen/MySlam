#include "adas_signal.h"

namespace shadow {

namespace adas {

std_msgs::Bool adasmsgFCWwarnBool; // FCW报警触发
std_msgs::Bool adasmsgAEBTriggerBool; // AEB功能触发
std_msgs::Bool adasmsgLDWTriggerBool; // LDW功能触发
std_msgs::Bool adasmsgBSDWarnBool; // BSD报警触发
std_msgs::Bool adasmsgTogglelanechangeBool; // 拨杆变道功能触发
std_msgs::Bool adasmsgOvertakingBool; // 超车功能触发
std_msgs::Bool adasmsgAPATriggerBool; // APA功能触发

} // !namespace adas

} // !namespace shadow
