#ifndef STRATEGY_JUDGES_H
#define STRATEGY_JUDGES_H

#include <unordered_map>
#include <string>
#include <unordered_set>
#include <vector>

namespace shadow {

enum Comparator {
  GREATER,
  GORE,
  LESS,
  LORE,
  EQUAL,
};

typedef struct {
  std::string signal;
  enum Comparator comparator;
  float base;
} CustomizedInfo;

class StrategyJudgeManager {
 public:
  StrategyJudgeManager();
  ~StrategyJudgeManager();

  StrategyJudgeManager(const StrategyJudgeManager&) = delete;
  StrategyJudgeManager& operator=(const StrategyJudgeManager&) = delete;

  std::vector<int> AddJudge(const std::vector<CustomizedInfo>& info);
  void AddJudge(const CustomizedInfo& info, const int judge_id);

  bool Result(const int id);
 private:
  template<typename T>
  bool CustomizedJudge(
      const T& signal, const CustomizedInfo& info);

  bool ConfirmSignal(const CustomizedInfo& info);

  std::unordered_map<int, bool(*)()> trigger_judge_list_;
  std::unordered_map<int, CustomizedInfo> customized_judge_list_;

  int customized_judge_size_;
};

// Judge Declaration
#pragma region 

// id1 手动立刻触发模式
static bool strategy_id1_trigger_judge();

// id2 驾驶员猛踩刹车（制动踏板开度及速率） 
static bool strategy_id2_trigger_judge();

// id3 驾驶员开启左转向灯（左转向灯信号）
static bool strategy_id3_trigger_judge();

// id4 驾驶员开启右转向灯（右转向灯信号）
static bool strategy_id4_trigger_judge();

// id5 驾驶员挂入倒挡（未到停车区）（档位信号）
static bool strategy_id5_trigger_judge();

// id6 驾驶员大幅度左转向（方向盘信号）
static bool strategy_id6_trigger_judge();

// id7 驾驶员大幅度右转向（方向盘信号）
static bool strategy_id7_trigger_judge();

// id8 进入隧道（场景识别）
static bool strategy_id8_trigger_judge();

// id9 出隧道（场景识别）
static bool strategy_id9_trigger_judge();

// id10 自定义施工区域（连续锥桶）（感知锥桶）
static bool strategy_id10_trigger_judge();

// id11 自定义行人密集区触发（感知行人密度）
static bool strategy_id11_trigger_judge();

// id12 自定义特种车辆检测触发（感知车辆类别（特种车辆））
static bool strategy_id12_trigger_judge();

// id13 驾驶员猛打方向盘 (方向盘转角及转角速率)
static bool strategy_id13_trigger_judge();

// id14 驾驶员鸣笛（喇叭信号）
static bool strategy_id14_trigger_judge();

// id15 驾驶员开启双闪灯(双闪灯信号)
static bool strategy_id15_trigger_judge();

// id16 驾驶员连续两次开启远光灯(远光灯信号)
static bool strategy_id16_trigger_judge();

// id17 车辆纵向加速度峰值过高(纵向加速度)
static bool strategy_id17_trigger_judge();

// id18 车辆横向加速度峰值过高(横向加速度)
static bool strategy_id18_trigger_judge();

// id19 车辆垂向加速度峰值过高(垂向加速度)
static bool strategy_id19_trigger_judge();

// id20 胎压异常过低(胎压)
static bool strategy_id20_trigger_judge();

// id21 车辆故障灯(故障信号)
static bool strategy_id21_trigger_judge();

// id22 较大下坡路段触发(IMU姿态传感器)
static bool strategy_id22_trigger_judge();

// id23 较大上坡路段触发(IMU姿态传感器)
static bool strategy_id23_trigger_judge();

// id24 当行驶到指定地点GPS时触发(GPS数据定位)
static bool strategy_id24_trigger_judge();

// id25 自定义时间触发(时间)
static bool strategy_id25_trigger_judge();

// id26 闯红灯(红绿灯检测)
static bool strategy_id26_trigger_judge();

// id27 超速(限速牌检测)
static bool strategy_id27_trigger_judge();

// id28 堵车(场景识别)
static bool strategy_id28_trigger_judge();

// id29 交通灯红灯触发(红绿灯检测)
static bool strategy_id29_trigger_judge();

// id30 交通限速牌触发(限速牌检测)
static bool strategy_id30_trigger_judge();

// id31 自定义雨天触发(感知天气)
static bool strategy_id31_trigger_judge();

// id32 自定义特殊交通牌触发(感知交通牌)
static bool strategy_id32_trigger_judge();

// id33 自定义遇到儿童触发(感知行人类别)
static bool strategy_id33_trigger_judge();

// id34 自定义特种车辆检测触发(感知车辆类别（特种车辆))
static bool strategy_id34_trigger_judge();

// id35 FCW(前方碰撞预警系统)报警触发(ADAS功能)
static bool strategy_id35_trigger_judge();

// id36 AEB(自动紧急制动系统)功能触发(ADAS功能)
static bool strategy_id36_trigger_judge();

// id37 LDW(车道偏移预警系统)功能触发(ADAS功能)
static bool strategy_id37_trigger_judge();

// id38 BSD（盲区监测系统）报警触发(ADAS功能)
static bool strategy_id38_trigger_judge();

// id39 拨杆变道功能触发(ADAS功能)
static bool strategy_id39_trigger_judge();

// id40 超车功能触发(ADAS功能)
static bool strategy_id40_trigger_judge();

// id41 APA（自动泊车）功能触发(ADAS功能)
static bool strategy_id41_trigger_judge();

#pragma endregion



} // !shadow

#endif // !STRATEGY_JUDGES_H
