#ifndef ADAS_SIGNAL_H
#define ADAS_SIGNAL_H

#include "std_msgs/Bool.h"

namespace shadow {

namespace adas {

extern std_msgs::Bool adasmsgFCWwarnBool; // FCW报警触发
extern std_msgs::Bool adasmsgAEBTriggerBool; // AEB功能触发
extern std_msgs::Bool adasmsgLDWTriggerBool; // LDW功能触发ss
extern std_msgs::Bool adasmsgBSDWarnBool; // BSD报警触发
extern std_msgs::Bool adasmsgTogglelanechangeBool; // 拨杆变道功能触发
extern std_msgs::Bool adasmsgOvertakingBool; // 超车功能触发
extern std_msgs::Bool adasmsgAPATriggerBool; // APA功能触发

} // !namespace adas

} // !namespace shadow
#endif // !ADAS_SIGNAL_H
