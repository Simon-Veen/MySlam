#include "strategy_signal.h"



namespace shadow {



namespace strategy {



std::unordered_map<int, Strategy> mapper;

StrategyJudgeManager judge;



} // !namespace strategy



} // !namespace shadow
