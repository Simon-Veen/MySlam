#ifndef PERCEP_SIGNAL_H
#define PERCEP_SIGNAL_H

#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Int8.h"
#include "std_msgs/Bool.h"

namespace shadow {

namespace perception {

extern std_msgs::Bool msgHumdensityBool; // 感知行人密度
extern std_msgs::Bool msgConeBool; // 感知锥桶
extern std_msgs::Bool msgIlluminationBool; // 感知光照
extern std_msgs::Bool msgTrafficLightBool; // 红绿灯检测
extern std_msgs::Bool msgSpeedlimitBool; // 限速牌检测
extern std_msgs::Int8 msgSceneDect; // 场景识别
extern std_msgs::Bool msgDectweatherBool; // 感知天气
extern std_msgs::Bool msgtrafficsignsBool; // 感知交通牌 
extern std_msgs::Bool msgHumancategoryBool; // 感知行人类别
extern std_msgs::Bool msgVehiclecategoryBool; // 感知车辆类别（特种车辆）


} // !namespace perception

}
#endif // !PERCEP_SIGNAL_H
