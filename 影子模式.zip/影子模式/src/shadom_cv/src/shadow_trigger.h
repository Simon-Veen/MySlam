#ifndef SHADOW_TRIGGER_H
#define SHADOW_TRIGGER_H

#include "std_msgs/String.h"
#include "ros/ros.h"
#include "xlite_manager.h"
#include "upload_manager.h"
#include "compress_manager.h"
#include "shadow_utils.h"

#include <unordered_map>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

namespace shadow {
 
class ShadowTrigger {
 public:
  ShadowTrigger(const std::string& config_path);
  ~ShadowTrigger();

  ShadowTrigger(const ShadowTrigger&) = delete;
  ShadowTrigger& operator=(const ShadowTrigger&) = delete;

  void UpdateStrategyFromCloudCMD(const std_msgs::String &msg);
  void CreateStrategyFromCloudCMD(const std_msgs::String &msg);

  void SentryTriggered(ros::Publisher& pub, std_msgs::String& msg);
  void ShadowTriggered(ros::Publisher& pub, std_msgs::String& msg);

  void EnableSentinel();
  void Sampler();

  TriggerLog* GetTriggerLog() { return &trigger_log_; }

 private:
  enum ParseIndex {
    EID = 1,
    ID,
    TYPE,
    WEIGHT,
    HZ,
    DURA,
    TM_START,
    TM_STOP,
    FREQ,
    SWITCH,
  };

  void InitConfig();

  bool SignalSampler();
  bool FrameSampler();
  void PopSampler();

  void ParseShadowCMD(enum ParseIndex parse_index, const std::string& src, std::string& dst);
  template<typename T> 
  void ParseShadowCMD(enum ParseIndex parse_index, const std::string& src, 
      std::vector<T>& dst, const char mark = '|');
  void ParseShadowCMD(enum ParseIndex parse_index, const std::string& src, 
      std::vector<std::string>& dst, const char mark = '|');
  void ParseShadowCMD(enum ParseIndex parse_index, const std::string& src, int64_t& dst);

  void Type2JudgeId(const std::string& src, std::vector<int>& dst, const char mark = '+');

  void ShadowLogSentry(std_msgs::String& msgShadowLog, const int id, const std::string& eid);
  void ShadowLog(std_msgs::String& msgShadowLog, const Strategy& strategy);

  void DataBaseHandler(const Strategy& strategy, const int secs, const int hz);
  void DataCloudHandler(const Strategy& strategy, const int secs, const int hz);

  void UpdateTriggeredTimes(Strategy& sty, const int64_t& now);

  bool SolidifyStrategyFromCloudCMD(const int strategy_id, const std::vector<int>& judge_ids,
      const std::vector<CustomizedInfo>& customied_infos, const std::vector<enum Logic>& logics);

  void LoadStrategy();

  std::string config_path_;
  std::unordered_map<int, std::string> id_type_;

  bool enable_sentinel_;

  cv::VideoCapture capture_;
  int sampler_size_;

  TriggerLog trigger_log_;
  XliteManager xlite_manager_;
  UploadManager upload_manager_;
  CompressManager compress_manager_;
};

} // !namespace shadow

#endif // !SHADOW_TRIGGER_H


