#include "ros/ros.h"
#include "std_msgs/String.h"
#include "can_msgs/Frame.h"

//ros::Publisher can_pub = nh.advertise<std_msgs::String>("can_talker",10);
//can_msg.data 是 unsigned char类型

void msg2_pub(ros::Publisher can_pub){
    // id2 驾驶员猛踩刹车（制动踏板开度及速率）,01_001
    can_msgs::Frame can_msg;
    can_msg.id = 0x350;
    can_msg.data={91,0,50,0,0,0,0,0};
    can_pub.publish(can_msg);
}
void msg3_pub(ros::Publisher can_pub){
    // id3 驾驶员开启左转向灯（左转向灯信号）,01_006
    can_msgs::Frame can_msg;
    can_msg.id = 0x370;
    can_msg.data={0,32,0,0,0,0,0,0};
    can_pub.publish(can_msg);    
}
void msg4_pub(ros::Publisher can_pub){
    // id4 驾驶员开启右转向灯（右转向灯信号），01_007
    can_msgs::Frame can_msg;
    can_msg.id = 0x370;
    can_msg.data={0,16,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
}
void msg3_4_pub(ros::Publisher can_pub){
    // 左右转向灯同时触发
    can_msgs::Frame can_msg;
    can_msg.id = 0x370;
    can_msg.data={0,48,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
}
void msg5_pub(ros::Publisher can_pub){
    // id5 驾驶员挂入倒挡（未到停车区）（档位信号）,01_008
    can_msgs::Frame can_msg;
    can_msg.id = 0x350;
    can_msg.data={0,0,0,0,0,0,32,0};
    can_pub.publish(can_msg); 
}
void msg6_pub(ros::Publisher can_pub){
    // id6 驾驶员大幅度左转向（方向盘信号）,01_009
    can_msgs::Frame can_msg;
    can_msg.id = 0x351;
    can_msg.data={94,28,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
}
void msg7_pub(ros::Publisher can_pub){
    // id7 驾驶员大幅度右转向（方向盘信号）,01_010
    can_msgs::Frame can_msg;
    can_msg.id = 0x351;
    can_msg.data={0,118,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
}
void msg13_pub(ros::Publisher can_pub)
{
    // id13 驾驶员猛打方向盘 (方向盘转角及转角速率),01_002
    can_msgs::Frame can_msg;
    can_msg.id = 0x351;
    can_msg.data={0,8,0,0,0,0,0,0};
    can_pub.publish(can_msg); 

    ros::Duration(0.5).sleep();

    can_msg.data={0,15,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
 
}
void msg14_pub(ros::Publisher can_pub){
    // id14 驾驶员鸣笛（喇叭信号），01_003
    can_msgs::Frame can_msg;
    can_msg.id = 0x360;
    can_msg.data={0,2,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
}
void msg15_pub(ros::Publisher can_pub){
    // id15 驾驶员开启双闪灯(双闪灯信号)，01_004
    can_msgs::Frame can_msg;
    can_msg.id = 0x360;
    can_msg.data={0,64,0,0,0,0,0,0};
    can_pub.publish(can_msg); 
}
void msg16_pub(ros::Publisher can_pub){
    // id16 驾驶员连续两次开启远光灯(远光灯信号),01_005
    can_msgs::Frame can_msg;
    can_msg.id = 0x360;
    can_msg.data={0,0b10000000,0,0,0,0,0,0};
    can_pub.publish(can_msg); 

    ros::Duration(0.5).sleep();

    can_pub.publish(can_msg);

}
void msg17_pub(ros::Publisher can_pub){
    // id17 车辆纵向加速度峰值过高(纵向加速度),02_001

    can_msgs::Frame can_msg;
    ros::Duration(1.0).sleep();
    can_msg.id = 0x350;
    can_msg.data={0,0,0,0,10,0,0,0};
    can_pub.publish(can_msg); 

    ros::Duration(1.0).sleep();
    can_msg.data={0,0,0,0,90,0,0,0};
    can_pub.publish(can_msg); 

    ros::Duration(1.0).sleep();
    can_msg.data={0,0,0,0,180,0,0,0};
    can_pub.publish(can_msg); 

    ros::Duration(100.0).sleep();

}


int main(int argc, char *argv[])
{
    ros::init(argc,argv,"can_talker");
    ros::NodeHandle nh;
    ros::Publisher can_pub = nh.advertise<can_msgs::Frame>("received_messages",10);

    ros::Rate loop_rate(10);

    int count=0;
    //fsd4_000001,14,01_003,1.0,1676901600000,1708610400000,1|100,On
    while(ros::ok()){
        can_msgs::Frame can_msg;
        //msg3_4_pub(can_pub);
        msg5_pub(can_pub);
        ros::spinOnce();
        loop_rate.sleep();
        count++;

    }
    return 0;
}
