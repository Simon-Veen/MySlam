//on car_nezhaU ,20230131 ,ros to ctrl car ,from gujun


#include"ros/ros.h"
#include <can_msgs/Frame.h>
#include <can_msgs/rtkmsg.h>
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Int8.h"
#include "std_msgs/Bool.h"
#include <sstream>
#include <string>

#include <nav_msgs/Path.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/PoseStamped.h>
#include <iostream> 
#include <fstream> 
using namespace std; 

//task1:get car message
std_msgs::Float32 msgVehicleSpeed;
std_msgs::Float32 msgSteeringAngle;
std_msgs::Float32 msgAccelPedalPosition;
std_msgs::Int8 msgGearPosition;

std_msgs::Int8 msgDriveMode;
std_msgs::Float32 msgBrakePedalPosition;
std_msgs::Bool msgShakeLStBool;
std_msgs::Bool msgShakeHStBool;
std_msgs::Bool msgBrakeModeStBool;

can_msgs::Frame CANsub_msgs_ID_0X350;//848
can_msgs::Frame CANsub_msgs_ID_0X351;//849

//RTX
can_msgs::Frame CANsub_msgs_ID_0x500;//1280
can_msgs::Frame CANsub_msgs_ID_0x501;//1281
can_msgs::Frame CANsub_msgs_ID_0x502;//1282
can_msgs::Frame CANsub_msgs_ID_0x503;//1283
can_msgs::Frame CANsub_msgs_ID_0x504;
can_msgs::Frame CANsub_msgs_ID_0x505;
can_msgs::Frame CANsub_msgs_ID_0x506;
can_msgs::Frame CANsub_msgs_ID_0x507;
can_msgs::Frame CANsub_msgs_ID_0x508;//1288
//RTX signal
// INS_Acc(0x500);//加速度计:惯导轴
std_msgs::Float32 msgINS_Acc_x;
std_msgs::Float32 msgINS_Acc_y;
std_msgs::Float32 msgINS_Acc_z;
// INS_GYRO(0x501);//陀螺惯导轴
std_msgs::Float32 msgINS_GYRO_x;
std_msgs::Float32 msgINS_GYRO_y;
std_msgs::Float32 msgINS_GYRO_z;
// INS_HeadingPitchRoll(0x502);
std_msgs::Float32 msgINS_PitchAngle;
std_msgs::Float32 msgINS_RollAngle;
std_msgs::Float32 msgINS_HeadingPitchAngle;
// INS_HeightAndTime(0x503);
std_msgs::Float32 msgINS_LocatHeight;
std_msgs::Float32 msgINS_Time;
// INS_LatitudeLongitude(0x504);
std_msgs::Float64 msgINS_Latitude;
std_msgs::Float64 msgINS_Longitude;
// INS_Speed(0x505);
std_msgs::Float32 msgINS_NorthSpd;
std_msgs::Float32 msgINS_EastSpd;
std_msgs::Float32 msgINS_ToGroundSpd;
// INS_DataInfo(0x506);
std_msgs::Int8 msgINS_GpsFlag_Pos;
std_msgs::Int8 msgINS_NumSV;
std_msgs::Int8 msgINS_GpsFlag_Heading;
std_msgs::Int8 msgINS_Gps_Age;
std_msgs::Int8 msgINS_Car_Status;
std_msgs::Int8 msgINS_INS_Status;
// INS_Std(0x507);
std_msgs::Float32 msgINS_Std_Lat;
std_msgs::Float32 msgINS_Std_Lon;
std_msgs::Float32 msgINS_Std_LocatHeight;
std_msgs::Float32 msgINS_Std_Heading;
// GPS(0x508);
std_msgs::Int8 msgUTC_year;
std_msgs::Int8 msgUTC_month;
std_msgs::Int8 msgUTC_day;
std_msgs::Int8 msgUTC_hour;
std_msgs::Int8 msgUTC_min;
std_msgs::Int8 msgUTC_sec;
std_msgs::Int8 msgUTC_msec;
  double x,y;
void CANmsgsCallback(const can_msgs::Frame& msg) //need to update to match can dbc
{

//    ROS_INFO("can_ID:[%d]",msg.id);
    

    

    //RTK  can to msg

     if (msg.id ==1280) //0X500=1280
    {
      CANsub_msgs_ID_0x500.data=msg.data;    
           		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
                //(msg.data[0]*256+msg.data[1])
      msgINS_Acc_x.data= float(0.0001220703125*(msg.data[0]*256+msg.data[1]))-4;///////need to test
      //ROS_INFO("msgINS_Acc_x:[%f]",msgINS_Acc_x.data);  
      msgINS_Acc_y.data= float(0.0001220703125*(msg.data[2]*256+msg.data[3]))-4;///////need to test
      //ROS_INFO("msgINS_Acc_y:[%f]",msgINS_Acc_y.data);  
      msgINS_Acc_z.data= float(0.0001220703125*(msg.data[4]*256+msg.data[5]))-4;///////need to test
      //ROS_INFO("msgINS_Acc_z:[%f]",msgINS_Acc_z.data);  
      
      ofstream rtkfile;
      rtkfile.open("rtkTrajectory.csv",ios::app);
      rtkfile << "INS_Acc(xyz):" << msgINS_Acc_x.data << "," << msgINS_Acc_y.data << "," << msgINS_Acc_z.data<<std::endl;
    }

  else if (msg.id ==848) //0X350=848
    {
      CANsub_msgs_ID_0X350.data=msg.data;
      //ROS_INFO("msgBrakePedalPosition[0]:[%d]",msg.data[1]);       
      msgBrakePedalPosition.data= float(1*msg.data[0]);//match jiyu   
      ROS_INFO("msgBrakePedalPosition:[%f]",msgBrakePedalPosition.data);  
      msgAccelPedalPosition.data= float(msg.data[2]);//need to update
      ROS_INFO("msgAccelPedalPosition:[%f]",msgAccelPedalPosition.data);  
      msgVehicleSpeed.data= float(0.1*(msg.data[5]*256+msg.data[4]));//match jiyu          
      ROS_INFO("msgVehicleSpeed:[%f]",msgVehicleSpeed.data);  
      //      
      msgShakeLStBool.data=int(msg.data[6]/128);//shake_L
      ROS_INFO("msgShakeLStBool:[%d]",msgShakeLStBool.data);  
      msgBrakeModeStBool.data= int(int(msg.data[6]/64)%2);   //brake_mode
      ROS_INFO("msgBrakeModeStBool:[%d]",msgBrakeModeStBool.data);  
      msgGearPosition.data=int(int(msg.data[6]/16)%4);//gear
      ROS_INFO("msgGearPosition:[%d]",msgGearPosition.data);  

      ofstream rtkfile;
    rtkfile.open("rtkTrajectory.csv",ios::app);
    rtkfile <<"INS_Speed:"<< msgVehicleSpeed.data<<std::endl
            <<"INS_Gear:"<< std::to_string(msgGearPosition.data)<<std::endl;
      
      
    }      
    else if (msg.id ==849) //0X351=849
    {
      CANsub_msgs_ID_0X351.data=msg.data;    
     
      msgSteeringAngle.data= float(0.05*(msg.data[1]*256+msg.data[0]));///////need to test
      
      if (msgSteeringAngle.data>900) //to right
      {
      msgSteeringAngle.data=msgSteeringAngle.data-3276.8;///////need to test
      }
           
      //ROS_INFO("msgSteeringAngle:[%f]",msgSteeringAngle.data);          
      //msgDriveMode.data= 1*msg.data[0];//match jiyu not easy
     
      msgShakeHStBool.data= int(msg.data[6]/128);//  
      //ROS_INFO("msgShakeHStBool:[%d]",msgShakeHStBool.data);                
      ofstream rtkfile;
      rtkfile.open("rtkTrajectory.csv",ios::app);
      rtkfile <<"INS_STEER:"<< msgSteeringAngle.data <<std::endl;
    }

    else if (msg.id ==1281) //0X500=1280
    {
      CANsub_msgs_ID_0x501.data=msg.data;    
           		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
                //(msg.data[0]*256+msg.data[1])
      msgINS_GYRO_x.data= float(0.0076293*(msg.data[0]*256+msg.data[1]))-250;///////need to test
      //ROS_INFO("msgINS_GYRO_x:[%f]",msgINS_GYRO_x.data); 
      msgINS_GYRO_y.data= float(0.0076293*(msg.data[2]*256+msg.data[3]))-250;///////need to test
      //ROS_INFO("msgINS_GYRO_y:[%f]",msgINS_GYRO_y.data); 
      msgINS_GYRO_z.data= float(0.0076293*(msg.data[4]*256+msg.data[5]))-250;///////need to test
      //ROS_INFO("msgINS_GYRO_z:[%f]",msgINS_GYRO_z.data); 
    }

    else if (msg.id ==1282) //0X500=1280
    {
      CANsub_msgs_ID_0x502.data=msg.data;    
           		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
                //(msg.data[0]*256+msg.data[1])
      msgINS_PitchAngle.data= float(0.010986*(msg.data[0]*256+msg.data[1]))-360;///////need to test
      //ROS_INFO("msgINS_PitchAngle:[%f]",msgINS_PitchAngle.data); 
      msgINS_RollAngle.data= float(0.010986*(msg.data[2]*256+msg.data[3]))-360;///////need to test
      //ROS_INFO("msgINS_RollAngle:[%f]",msgINS_RollAngle.data); 
      msgINS_HeadingPitchAngle.data= float(0.010986*(msg.data[4]*256+msg.data[5]))-360;///////need to test
      //ROS_INFO("msgINS_HeadingPitchAngle:[%f]",msgINS_HeadingPitchAngle.data); 
      
      ofstream rtkfile;
      rtkfile.open("rtkTrajectory.csv",ios::app);
      rtkfile <<"INS_ANGLE(PRH):"<< msgINS_PitchAngle.data << "," << msgINS_RollAngle.data << "," << msgINS_HeadingPitchAngle.data<<std::endl;

    }

   else  if (msg.id ==1283) //0X500=1280
    {
     static  int count = 0;
    
      CANsub_msgs_ID_0x503.data=msg.data;    
       ROS_INFO("CANsub_msgs_ID_0x503:[%d]",CANsub_msgs_ID_0x503.data); 
           		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
                //(msg.data[0]*256+msg.data[1])
       uint64_t val=(uint64_t(msg.data[0])<<24)|(uint64_t(msg.data[1])<<16)|(uint64_t(msg.data[2])<<8)|(uint64_t(msg.data[3]));
      msgINS_LocatHeight.data= float(0.001*val)-10000;
 //     ROS_INFO("msgINS_LocatHeight:[%f]",msgINS_LocatHeight.data); 
      msgINS_Time.data=  float(1*((uint64_t(msg.data[4])<<24)|(uint64_t(msg.data[5])<<16)|(uint64_t(msg.data[6])<<8)|(uint64_t(msg.data[7]))));///////need to test
      
      ofstream rtkfile;
      rtkfile.open("rtkTrajectory.csv",ios::app);
      rtkfile.setf(ios::fixed, ios::floatfield);
      rtkfile <<"INS_TIMESTAMP:" << msgINS_Time.data <<std::endl;

      ROS_INFO("msgINS_Time:[%f]",msgINS_Time.data); 
    //   ROS_INFO("msgINS_Time:[%d]",count); 
       count++;

    }

     else if (msg.id ==1284) //0X500=1280
    {
  //    static  int coun = 0;
    //    for (int i = 0; i <8 ; i++)
    //  {
    //    CANsub_msgs_ID_0x504.data[i] = msg.data[i];
    //     ROS_INFO("msg.data:[%d]",msg.data[i]); 
    //  }
      //CANsub_msgs_ID_0x504.data=msg.data;    
       CANsub_msgs_ID_0x504.data=msg.data;   
       ROS_INFO("CANsub_msgs_ID_0x504:[%d]",CANsub_msgs_ID_0x504.data); 
      ROS_INFO("msg.data:[%d]",msg.data); 
       
           		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
                //(msg.data[0]*256+msg.data[1])
      uint64_t val=(uint64_t(msg.data[0])<<24)|(uint64_t(msg.data[1])<<16)|(uint64_t(msg.data[2])<<8)|(uint64_t(msg.data[3]));
    // uint64_t val=uint64_t(msg.data[0]) * 256*3 +uint64_t(msg.data[1])*256*2 + uint64_t(msg.data[2])*256+uint64_t(msg.data[3]);
      msgINS_Latitude.data= double(0.0000001*val)-180;///////need to test
      long double a =double(0.0000001*val)-180;
       ROS_INFO("val:[%d]",val); 
       ROS_INFO("a:[%f]",a); 

      ROS_INFO("msgINS_Latitude:[%f]",msgINS_Latitude.data); 
      msgINS_Longitude.data= double(0.0000001*((uint64_t(msg.data[4])<<24)|(uint64_t(msg.data[5])<<16)|(uint64_t(msg.data[6])<<8)|(uint64_t(msg.data[7]))))-180;///////need to test
      ROS_INFO("msgINS_Longitude:[%f]",msgINS_Longitude.data); 
     // ROS_INFO("msgINS_Longitude:[%d]",coun); 
     //  coun++;

    }

    // else if (msg.id ==1285) //0X500=1280
    // {
    //   CANsub_msgs_ID_0x505.data=msg.data;    
    //        		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
    //             //(msg.data[0]*256+msg.data[1])
    //   msgINS_NorthSpd.data= float(0.0030517*(msg.data[0]*256+msg.data[1]))-100;///////need to test
    //   //ROS_INFO("msgINS_NorthSpd:[%f]",msgINS_NorthSpd.data); 
    //   msgINS_EastSpd.data= float(0.0030517*(msg.data[2]*256+msg.data[3]))-100;///////need to test
    //   //ROS_INFO("msgINS_EastSpd:[%f]",msgINS_EastSpd.data); 
    //   msgINS_ToGroundSpd.data= float(0.0030517*(msg.data[4]*256+msg.data[5]))-100;///////need to test
    //   //ROS_INFO("msgINS_ToGroundSpd:[%f]",msgINS_ToGroundSpd.data); 
    // }

    // else if (msg.id ==1286) //0X500=1280
    // {
    //   CANsub_msgs_ID_0x506.data=msg.data;    
    //        		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
    //             //(msg.data[0]*256+msg.data[1])
    //   msgINS_GpsFlag_Pos.data= int(1*(msg.data[0]));///////need to test
    //   //ROS_INFO("msgINS_GpsFlag_Pos:[%d]",msgINS_GpsFlag_Pos.data); 
    //   msgINS_NumSV.data= int(1*(msg.data[1]));///////need to test
    //   //ROS_INFO("msgINS_NumSV:[%d]",msgINS_NumSV.data); 
    //   msgINS_GpsFlag_Heading.data=  int(1*(msg.data[2]));///////need to test
    //   //ROS_INFO("msgINS_GpsFlag_Heading:[%d]",msgINS_GpsFlag_Heading.data); 
    //   msgINS_Gps_Age.data=  int(1*(msg.data[3]));///////need to test
    //   //ROS_INFO("msgINS_Gps_Age:[%d]",msgINS_Gps_Age.data); 
    //   msgINS_Car_Status.data=  int(1*(msg.data[4]));//////need to test
    //   //ROS_INFO("msgINS_Car_Status:[%d]",msgINS_Car_Status.data); 
    //   msgINS_INS_Status.data=  int(1*(msg.data[5]));///////need to test
    //   //ROS_INFO("msgINS_INS_Status:[%d]",msgINS_INS_Status.data); 

    // }

    // else if (msg.id ==1287) //0X500=1280
    // {
    //   CANsub_msgs_ID_0x507.data=msg.data;    
    //        		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
    //             //(msg.data[0]*256+msg.data[1])
    //   msgINS_Std_Lat.data= float(1*(msg.data[0]*256+msg.data[1]));///////need to test
    //   //ROS_INFO("msgINS_Std_Lat:[%f]",msgINS_Std_Lat.data); 
    //   msgINS_Std_Lon.data= float(1*(msg.data[2]*256+msg.data[3]));///////need to test
    //   //ROS_INFO("msgINS_Std_Lon:[%f]",msgINS_Std_Lon.data); 
    //   msgINS_Std_LocatHeight.data= float(1*(msg.data[4]*256+msg.data[5]));///////need to test
    //   //ROS_INFO("msgINS_Std_LocatHeight:[%f]",msgINS_Std_LocatHeight.data); 
    //   msgINS_Std_Heading.data= float(1*(msg.data[6]*256+msg.data[7]));///////need to test
    //   //ROS_INFO("msgINS_Std_Heading:[%f]",msgINS_Std_Heading.data); 
    // }

    // else if (msg.id ==1288) //0X500=1280
    // {
    //   CANsub_msgs_ID_0x508.data=msg.data;    
    //        		//((uint16)pdat[0] << 8) | ((uint16)(pdat[1]) >> 0);
    //             //(msg.data[0]*256+msg.data[1])
    //   msgUTC_year.data= int(1*(msg.data[0]));///////need to test
    //   //ROS_INFO("msgUTC_year:[%d]",msgUTC_year.data); 
    //   msgUTC_month.data= int(1*(msg.data[1]));///////need to test
    //   //ROS_INFO("msgUTC_month:[%d]",msgUTC_month.data); 
    //   msgUTC_day.data=  int(1*(msg.data[2]));///////need to test
    //   //ROS_INFO("msgUTC_day:[%d]",msgUTC_day.data); 
    //   msgUTC_hour.data=  int(1*(msg.data[3]));///////need to test
    //   //ROS_INFO("msgUTC_hour:[%d]",msgUTC_hour.data); 
    //   msgUTC_min.data=  int(1*(msg.data[4]));//////need to test
    //   //ROS_INFO("msgUTC_min:[%d]",msgUTC_min.data); 
    //   msgUTC_sec.data=  int(1*(msg.data[5]));///////need to test
    //   //ROS_INFO("msgUTC_sec:[%d]",msgUTC_sec.data); 
    //   msgUTC_msec.data=  int(0.001*(msg.data[6]*256+msg.data[7]));///////need to test
    //   //ROS_INFO("msgUTC_msec:[%d]",msgUTC_msec.data); 

    // }

}



void LonLat2UTM(double longitude, double latitude)
{
	double lat = latitude;
	double lon = longitude;
    double UTME=0;
    double UTMN=0;
	double kD2R = 3.1415926 / 180.0;
	double ZoneNumber = floor((lon - 1.5) / 3.0) + 1;
	double L0 = ZoneNumber * 3.0;

	double a = 6378137.0;
	double F = 298.257223563;
	double f = 1 / F;
	double b = a * (1 - f);
	double ee = (a * a - b * b) / (a * a);
	double e2 = (a * a - b * b) / (b * b);
	double n = (a - b) / (a + b); 
	double n2 = (n * n); 
	double n3 = (n2 * n); 
	double n4 = (n2 * n2); 
	double n5 = (n4 * n);
	double al = (a + b) * (1 + n2 / 4 + n4 / 64) / 2.0;
	double bt = -3 * n / 2 + 9 * n3 / 16 - 3 * n5 / 32.0;
	double gm = 15 * n2 / 16 - 15 * n4 / 32;
	double dt = -35 * n3 / 48 + 105 * n5 / 256;
	double ep = 315 * n4 / 512;
	double B = lat * kD2R;
	double L = lon * kD2R;
	L0 = L0 * kD2R;
	double l = L - L0; 
	double cl = (cos(B) * l); 
	double cl2 = (cl * cl); 
	double cl3 = (cl2 * cl); 
	double cl4 = (cl2 * cl2); 
	double cl5 = (cl4 * cl); 
	double cl6 = (cl5 * cl); 
	double cl7 = (cl6 * cl); 
	double cl8 = (cl4 * cl4);
	double lB = al * (B + bt * sin(2 * B) + gm * sin(4 * B) + dt * sin(6 * B) + ep * sin(8 * B));
	double t = tan(B); 
	double t2 = (t * t); 
	double t4 = (t2 * t2); 
	double t6 = (t4 * t2);
	double Nn = a / sqrt(1 - ee * sin(B) * sin(B));
	double yt = e2 * cos(B) * cos(B);
	double N = lB;
	N = N + t * Nn * cl2 / 2;
	N = N + t * Nn * cl4 * (5 - t2 + 9 * yt + 4 * yt * yt) / 24;
	N = N + t * Nn * cl6 * (61 - 58 * t2 + t4 + 270 * yt - 330 * t2 * yt) / 720;
	N = N + t * Nn * cl8 * (1385 - 3111 * t2 + 543 * t4 - t6) / 40320;
	double E = Nn * cl;
	E = E + Nn * cl3 * (1 - t2 + yt) / 6;
	E = E + Nn * cl5 * (5 - 18 * t2 + t4 + 14 * yt - 58 * t2 * yt) / 120;
	E = E + Nn * cl7 * (61 - 479 * t2 + 179 * t4 - t6) / 5040;
	E = E + 500000;
	N = 0.9996 * N;
	E = 0.9996 * (E - 500000.0) + 500000.0;

	x = E;
	y = N;
   // std::cout << "x," << UTME <<",y," << UTMN<< std::endl;
}

void ctrlGearPositionCallback(const std_msgs::Int8::ConstPtr& msg)
{
    // ROS_INFO("ctrlGearPosition:[%d]",msg->data);
    // msgctrlGearPosition.data=msg->data;


    //std::cout<<" chatterCallback run"<<std::endl;
}
void ctrlSteeringAngleCallback(const std_msgs::Float32::ConstPtr& msg)
{
    ROS_INFO("ctrlSteeringAngle:[%f]",msg->data);
    msgSteeringAngle.data=msg->data;


    //std::cout<<" chatterCallback run"<<std::endl;
}
int main(int argc, char *argv[])
{
	setlocale(LC_ALL,"");
	ros::init(argc,argv,"can_ros");
	ros::NodeHandle n;

	//sub from CAN
	ros::Subscriber sub_CANmsgs = n.subscribe("received_messages",1000,CANmsgsCallback);
  ros::Publisher rtk_pub=n.advertise<can_msgs::rtkmsg>("rtkmsg",1); //sent CAN message

	//ros::Subscriber sub_ctrlSteeringAngle = n.subscribe("/ctrlSteeringAngle",1,ctrlSteeringAngleCallback);
	//ros::Subscriber sub_ctrlGearPosition = n.subscribe("/ctrlGearPosition",1,ctrlGearPositionCallback);






   ofstream rtkfile_1;
   rtkfile_1.open("rtk_path.csv",ios::app);
    
	ros::Rate loop_rate(20);//
	int count = 0;
	

  while (ros::ok())
  {

    can_msgs::rtkmsg  rtkmsg;
    rtkmsg.msgiNS_Acc_x=msgINS_Acc_x.data;
    rtkmsg.msgiNS_Acc_y=msgINS_Acc_y.data;
    rtkmsg.msgiNS_HeadingPitchAngle=msgINS_HeadingPitchAngle.data;
    rtkmsg.msgiNS_Latitude=msgINS_Latitude.data;
    rtkmsg.msgiNS_Longitude=msgINS_Longitude.data;
    rtkmsg.msgiNS_GYRO_z=msgINS_GYRO_z.data;
    rtkmsg.msgiNS_Time=msgINS_Time.data;

    LonLat2UTM(msgINS_Longitude.data, msgINS_Latitude.data);
    rtkmsg.x=x-617716;  
    rtkmsg.y=y-3474590;


    rtkfile_1 << std::setprecision(13) << rtkmsg.x    << ","<< std::setprecision(13) << rtkmsg.y   << endl;
    //rtk_pub.publish(rtkmsg);

    ros::spinOnce();
    loop_rate.sleep();
    ++count;
  }
    ros::spin();  
    return 0;
}

