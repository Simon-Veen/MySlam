# -*- coding: utf-8 -*-

import csv
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

import math


file_4='rtk_path.csv'
with open(file_4,'r') as csvfile:
    reader = csv.reader(csvfile)
    pose_x=[]
    pose_y=[]
    for row in reader:
        pose_x.append(float(row[0]))
        pose_y.append(float(row[1]))

plt.plot(pose_x,pose_y,label="RTK")
plt.legend()


plt.show()


