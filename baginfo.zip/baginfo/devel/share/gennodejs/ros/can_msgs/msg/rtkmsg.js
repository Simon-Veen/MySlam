// Auto-generated. Do not edit!

// (in-package can_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class rtkmsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.msgiNS_Acc_x = null;
      this.msgiNS_Acc_y = null;
      this.msgiNS_Acc_z = null;
      this.msgiNS_GYRO_x = null;
      this.msgiNS_GYRO_y = null;
      this.msgiNS_GYRO_z = null;
      this.msgiNS_PitchAngle = null;
      this.msgiNS_RollAngle = null;
      this.msgiNS_HeadingPitchAngle = null;
      this.msgiNS_LocatHeight = null;
      this.msgiNS_Time = null;
      this.msgiNS_Latitude = null;
      this.msgiNS_Longitude = null;
      this.msgiNS_NorthSpd = null;
      this.msgiNS_EastSpd = null;
      this.msgiNS_ToGroundSpd = null;
      this.msgiNS_Gpsflag_Pos = null;
      this.msgiNS_NumSV = null;
      this.msgiNS_Gpsflag_Heading = null;
      this.msgiNS_Gps_Age = null;
      this.msgiNS_Car_Status = null;
      this.msgiNS_iNS_Status = null;
      this.msgiNS_Std_Lat = null;
      this.msgiNS_Std_Lon = null;
      this.msgiNS_Std_LocatHeight = null;
      this.msgiNS_Std_Heading = null;
      this.msgUTC_year = null;
      this.msgUTC_month = null;
      this.msgUTC_day = null;
      this.msgUTC_hour = null;
      this.msgUTC_min = null;
      this.msgUTC_sec = null;
      this.msgUTC_msec = null;
      this.x = null;
      this.y = null;
    }
    else {
      if (initObj.hasOwnProperty('msgiNS_Acc_x')) {
        this.msgiNS_Acc_x = initObj.msgiNS_Acc_x
      }
      else {
        this.msgiNS_Acc_x = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Acc_y')) {
        this.msgiNS_Acc_y = initObj.msgiNS_Acc_y
      }
      else {
        this.msgiNS_Acc_y = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Acc_z')) {
        this.msgiNS_Acc_z = initObj.msgiNS_Acc_z
      }
      else {
        this.msgiNS_Acc_z = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_GYRO_x')) {
        this.msgiNS_GYRO_x = initObj.msgiNS_GYRO_x
      }
      else {
        this.msgiNS_GYRO_x = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_GYRO_y')) {
        this.msgiNS_GYRO_y = initObj.msgiNS_GYRO_y
      }
      else {
        this.msgiNS_GYRO_y = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_GYRO_z')) {
        this.msgiNS_GYRO_z = initObj.msgiNS_GYRO_z
      }
      else {
        this.msgiNS_GYRO_z = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_PitchAngle')) {
        this.msgiNS_PitchAngle = initObj.msgiNS_PitchAngle
      }
      else {
        this.msgiNS_PitchAngle = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_RollAngle')) {
        this.msgiNS_RollAngle = initObj.msgiNS_RollAngle
      }
      else {
        this.msgiNS_RollAngle = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_HeadingPitchAngle')) {
        this.msgiNS_HeadingPitchAngle = initObj.msgiNS_HeadingPitchAngle
      }
      else {
        this.msgiNS_HeadingPitchAngle = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_LocatHeight')) {
        this.msgiNS_LocatHeight = initObj.msgiNS_LocatHeight
      }
      else {
        this.msgiNS_LocatHeight = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Time')) {
        this.msgiNS_Time = initObj.msgiNS_Time
      }
      else {
        this.msgiNS_Time = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Latitude')) {
        this.msgiNS_Latitude = initObj.msgiNS_Latitude
      }
      else {
        this.msgiNS_Latitude = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Longitude')) {
        this.msgiNS_Longitude = initObj.msgiNS_Longitude
      }
      else {
        this.msgiNS_Longitude = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_NorthSpd')) {
        this.msgiNS_NorthSpd = initObj.msgiNS_NorthSpd
      }
      else {
        this.msgiNS_NorthSpd = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_EastSpd')) {
        this.msgiNS_EastSpd = initObj.msgiNS_EastSpd
      }
      else {
        this.msgiNS_EastSpd = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_ToGroundSpd')) {
        this.msgiNS_ToGroundSpd = initObj.msgiNS_ToGroundSpd
      }
      else {
        this.msgiNS_ToGroundSpd = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Gpsflag_Pos')) {
        this.msgiNS_Gpsflag_Pos = initObj.msgiNS_Gpsflag_Pos
      }
      else {
        this.msgiNS_Gpsflag_Pos = 0;
      }
      if (initObj.hasOwnProperty('msgiNS_NumSV')) {
        this.msgiNS_NumSV = initObj.msgiNS_NumSV
      }
      else {
        this.msgiNS_NumSV = 0;
      }
      if (initObj.hasOwnProperty('msgiNS_Gpsflag_Heading')) {
        this.msgiNS_Gpsflag_Heading = initObj.msgiNS_Gpsflag_Heading
      }
      else {
        this.msgiNS_Gpsflag_Heading = 0;
      }
      if (initObj.hasOwnProperty('msgiNS_Gps_Age')) {
        this.msgiNS_Gps_Age = initObj.msgiNS_Gps_Age
      }
      else {
        this.msgiNS_Gps_Age = 0;
      }
      if (initObj.hasOwnProperty('msgiNS_Car_Status')) {
        this.msgiNS_Car_Status = initObj.msgiNS_Car_Status
      }
      else {
        this.msgiNS_Car_Status = 0;
      }
      if (initObj.hasOwnProperty('msgiNS_iNS_Status')) {
        this.msgiNS_iNS_Status = initObj.msgiNS_iNS_Status
      }
      else {
        this.msgiNS_iNS_Status = 0;
      }
      if (initObj.hasOwnProperty('msgiNS_Std_Lat')) {
        this.msgiNS_Std_Lat = initObj.msgiNS_Std_Lat
      }
      else {
        this.msgiNS_Std_Lat = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Std_Lon')) {
        this.msgiNS_Std_Lon = initObj.msgiNS_Std_Lon
      }
      else {
        this.msgiNS_Std_Lon = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Std_LocatHeight')) {
        this.msgiNS_Std_LocatHeight = initObj.msgiNS_Std_LocatHeight
      }
      else {
        this.msgiNS_Std_LocatHeight = 0.0;
      }
      if (initObj.hasOwnProperty('msgiNS_Std_Heading')) {
        this.msgiNS_Std_Heading = initObj.msgiNS_Std_Heading
      }
      else {
        this.msgiNS_Std_Heading = 0.0;
      }
      if (initObj.hasOwnProperty('msgUTC_year')) {
        this.msgUTC_year = initObj.msgUTC_year
      }
      else {
        this.msgUTC_year = 0;
      }
      if (initObj.hasOwnProperty('msgUTC_month')) {
        this.msgUTC_month = initObj.msgUTC_month
      }
      else {
        this.msgUTC_month = 0;
      }
      if (initObj.hasOwnProperty('msgUTC_day')) {
        this.msgUTC_day = initObj.msgUTC_day
      }
      else {
        this.msgUTC_day = 0;
      }
      if (initObj.hasOwnProperty('msgUTC_hour')) {
        this.msgUTC_hour = initObj.msgUTC_hour
      }
      else {
        this.msgUTC_hour = 0;
      }
      if (initObj.hasOwnProperty('msgUTC_min')) {
        this.msgUTC_min = initObj.msgUTC_min
      }
      else {
        this.msgUTC_min = 0;
      }
      if (initObj.hasOwnProperty('msgUTC_sec')) {
        this.msgUTC_sec = initObj.msgUTC_sec
      }
      else {
        this.msgUTC_sec = 0;
      }
      if (initObj.hasOwnProperty('msgUTC_msec')) {
        this.msgUTC_msec = initObj.msgUTC_msec
      }
      else {
        this.msgUTC_msec = 0;
      }
      if (initObj.hasOwnProperty('x')) {
        this.x = initObj.x
      }
      else {
        this.x = 0.0;
      }
      if (initObj.hasOwnProperty('y')) {
        this.y = initObj.y
      }
      else {
        this.y = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type rtkmsg
    // Serialize message field [msgiNS_Acc_x]
    bufferOffset = _serializer.float32(obj.msgiNS_Acc_x, buffer, bufferOffset);
    // Serialize message field [msgiNS_Acc_y]
    bufferOffset = _serializer.float32(obj.msgiNS_Acc_y, buffer, bufferOffset);
    // Serialize message field [msgiNS_Acc_z]
    bufferOffset = _serializer.float32(obj.msgiNS_Acc_z, buffer, bufferOffset);
    // Serialize message field [msgiNS_GYRO_x]
    bufferOffset = _serializer.float32(obj.msgiNS_GYRO_x, buffer, bufferOffset);
    // Serialize message field [msgiNS_GYRO_y]
    bufferOffset = _serializer.float32(obj.msgiNS_GYRO_y, buffer, bufferOffset);
    // Serialize message field [msgiNS_GYRO_z]
    bufferOffset = _serializer.float32(obj.msgiNS_GYRO_z, buffer, bufferOffset);
    // Serialize message field [msgiNS_PitchAngle]
    bufferOffset = _serializer.float32(obj.msgiNS_PitchAngle, buffer, bufferOffset);
    // Serialize message field [msgiNS_RollAngle]
    bufferOffset = _serializer.float32(obj.msgiNS_RollAngle, buffer, bufferOffset);
    // Serialize message field [msgiNS_HeadingPitchAngle]
    bufferOffset = _serializer.float32(obj.msgiNS_HeadingPitchAngle, buffer, bufferOffset);
    // Serialize message field [msgiNS_LocatHeight]
    bufferOffset = _serializer.float32(obj.msgiNS_LocatHeight, buffer, bufferOffset);
    // Serialize message field [msgiNS_Time]
    bufferOffset = _serializer.float32(obj.msgiNS_Time, buffer, bufferOffset);
    // Serialize message field [msgiNS_Latitude]
    bufferOffset = _serializer.float32(obj.msgiNS_Latitude, buffer, bufferOffset);
    // Serialize message field [msgiNS_Longitude]
    bufferOffset = _serializer.float32(obj.msgiNS_Longitude, buffer, bufferOffset);
    // Serialize message field [msgiNS_NorthSpd]
    bufferOffset = _serializer.float32(obj.msgiNS_NorthSpd, buffer, bufferOffset);
    // Serialize message field [msgiNS_EastSpd]
    bufferOffset = _serializer.float32(obj.msgiNS_EastSpd, buffer, bufferOffset);
    // Serialize message field [msgiNS_ToGroundSpd]
    bufferOffset = _serializer.float32(obj.msgiNS_ToGroundSpd, buffer, bufferOffset);
    // Serialize message field [msgiNS_Gpsflag_Pos]
    bufferOffset = _serializer.int8(obj.msgiNS_Gpsflag_Pos, buffer, bufferOffset);
    // Serialize message field [msgiNS_NumSV]
    bufferOffset = _serializer.int8(obj.msgiNS_NumSV, buffer, bufferOffset);
    // Serialize message field [msgiNS_Gpsflag_Heading]
    bufferOffset = _serializer.int8(obj.msgiNS_Gpsflag_Heading, buffer, bufferOffset);
    // Serialize message field [msgiNS_Gps_Age]
    bufferOffset = _serializer.int8(obj.msgiNS_Gps_Age, buffer, bufferOffset);
    // Serialize message field [msgiNS_Car_Status]
    bufferOffset = _serializer.int8(obj.msgiNS_Car_Status, buffer, bufferOffset);
    // Serialize message field [msgiNS_iNS_Status]
    bufferOffset = _serializer.int8(obj.msgiNS_iNS_Status, buffer, bufferOffset);
    // Serialize message field [msgiNS_Std_Lat]
    bufferOffset = _serializer.float32(obj.msgiNS_Std_Lat, buffer, bufferOffset);
    // Serialize message field [msgiNS_Std_Lon]
    bufferOffset = _serializer.float32(obj.msgiNS_Std_Lon, buffer, bufferOffset);
    // Serialize message field [msgiNS_Std_LocatHeight]
    bufferOffset = _serializer.float32(obj.msgiNS_Std_LocatHeight, buffer, bufferOffset);
    // Serialize message field [msgiNS_Std_Heading]
    bufferOffset = _serializer.float32(obj.msgiNS_Std_Heading, buffer, bufferOffset);
    // Serialize message field [msgUTC_year]
    bufferOffset = _serializer.int8(obj.msgUTC_year, buffer, bufferOffset);
    // Serialize message field [msgUTC_month]
    bufferOffset = _serializer.int8(obj.msgUTC_month, buffer, bufferOffset);
    // Serialize message field [msgUTC_day]
    bufferOffset = _serializer.int8(obj.msgUTC_day, buffer, bufferOffset);
    // Serialize message field [msgUTC_hour]
    bufferOffset = _serializer.int8(obj.msgUTC_hour, buffer, bufferOffset);
    // Serialize message field [msgUTC_min]
    bufferOffset = _serializer.int8(obj.msgUTC_min, buffer, bufferOffset);
    // Serialize message field [msgUTC_sec]
    bufferOffset = _serializer.int8(obj.msgUTC_sec, buffer, bufferOffset);
    // Serialize message field [msgUTC_msec]
    bufferOffset = _serializer.int8(obj.msgUTC_msec, buffer, bufferOffset);
    // Serialize message field [x]
    bufferOffset = _serializer.float32(obj.x, buffer, bufferOffset);
    // Serialize message field [y]
    bufferOffset = _serializer.float32(obj.y, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type rtkmsg
    let len;
    let data = new rtkmsg(null);
    // Deserialize message field [msgiNS_Acc_x]
    data.msgiNS_Acc_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Acc_y]
    data.msgiNS_Acc_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Acc_z]
    data.msgiNS_Acc_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_GYRO_x]
    data.msgiNS_GYRO_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_GYRO_y]
    data.msgiNS_GYRO_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_GYRO_z]
    data.msgiNS_GYRO_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_PitchAngle]
    data.msgiNS_PitchAngle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_RollAngle]
    data.msgiNS_RollAngle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_HeadingPitchAngle]
    data.msgiNS_HeadingPitchAngle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_LocatHeight]
    data.msgiNS_LocatHeight = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Time]
    data.msgiNS_Time = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Latitude]
    data.msgiNS_Latitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Longitude]
    data.msgiNS_Longitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_NorthSpd]
    data.msgiNS_NorthSpd = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_EastSpd]
    data.msgiNS_EastSpd = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_ToGroundSpd]
    data.msgiNS_ToGroundSpd = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Gpsflag_Pos]
    data.msgiNS_Gpsflag_Pos = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgiNS_NumSV]
    data.msgiNS_NumSV = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Gpsflag_Heading]
    data.msgiNS_Gpsflag_Heading = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Gps_Age]
    data.msgiNS_Gps_Age = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Car_Status]
    data.msgiNS_Car_Status = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgiNS_iNS_Status]
    data.msgiNS_iNS_Status = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Std_Lat]
    data.msgiNS_Std_Lat = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Std_Lon]
    data.msgiNS_Std_Lon = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Std_LocatHeight]
    data.msgiNS_Std_LocatHeight = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgiNS_Std_Heading]
    data.msgiNS_Std_Heading = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msgUTC_year]
    data.msgUTC_year = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgUTC_month]
    data.msgUTC_month = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgUTC_day]
    data.msgUTC_day = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgUTC_hour]
    data.msgUTC_hour = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgUTC_min]
    data.msgUTC_min = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgUTC_sec]
    data.msgUTC_sec = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [msgUTC_msec]
    data.msgUTC_msec = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [x]
    data.x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [y]
    data.y = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 101;
  }

  static datatype() {
    // Returns string type for a message object
    return 'can_msgs/rtkmsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '227174dece87cfa9bbaf66684a8dc8ec';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # iNS_Acc(0x500)//加速度计:惯导轴
    float32 msgiNS_Acc_x
    float32 msgiNS_Acc_y
    float32 msgiNS_Acc_z
    #iNS_GYRO(0x501)//陀螺惯导轴
    float32 msgiNS_GYRO_x
    float32 msgiNS_GYRO_y
    float32 msgiNS_GYRO_z
    #iNS_HeadingPitchRoll(0x502)
    float32 msgiNS_PitchAngle
    float32 msgiNS_RollAngle
    float32 msgiNS_HeadingPitchAngle
    #iNS_HeightAndTime(0x503)
    float32 msgiNS_LocatHeight
    float32 msgiNS_Time
    #iNS_LatitudeLongitude(0x504)
    float32 msgiNS_Latitude
    float32 msgiNS_Longitude
    #iNS_Speed(0x505)
    float32 msgiNS_NorthSpd
    float32 msgiNS_EastSpd
    float32 msgiNS_ToGroundSpd
    #iNS_Datainfo(0x506)
    int8 msgiNS_Gpsflag_Pos
    int8 msgiNS_NumSV
    int8 msgiNS_Gpsflag_Heading
    int8 msgiNS_Gps_Age
    int8 msgiNS_Car_Status
    int8 msgiNS_iNS_Status
    #iNS_Std(0x507)
    float32 msgiNS_Std_Lat
    float32 msgiNS_Std_Lon
    float32 msgiNS_Std_LocatHeight
    float32 msgiNS_Std_Heading
    #GPS(0x508)
    int8 msgUTC_year
    int8 msgUTC_month
    int8 msgUTC_day
    int8 msgUTC_hour
    int8 msgUTC_min
    int8 msgUTC_sec
    int8 msgUTC_msec
    
    float32 x
    float32 y
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new rtkmsg(null);
    if (msg.msgiNS_Acc_x !== undefined) {
      resolved.msgiNS_Acc_x = msg.msgiNS_Acc_x;
    }
    else {
      resolved.msgiNS_Acc_x = 0.0
    }

    if (msg.msgiNS_Acc_y !== undefined) {
      resolved.msgiNS_Acc_y = msg.msgiNS_Acc_y;
    }
    else {
      resolved.msgiNS_Acc_y = 0.0
    }

    if (msg.msgiNS_Acc_z !== undefined) {
      resolved.msgiNS_Acc_z = msg.msgiNS_Acc_z;
    }
    else {
      resolved.msgiNS_Acc_z = 0.0
    }

    if (msg.msgiNS_GYRO_x !== undefined) {
      resolved.msgiNS_GYRO_x = msg.msgiNS_GYRO_x;
    }
    else {
      resolved.msgiNS_GYRO_x = 0.0
    }

    if (msg.msgiNS_GYRO_y !== undefined) {
      resolved.msgiNS_GYRO_y = msg.msgiNS_GYRO_y;
    }
    else {
      resolved.msgiNS_GYRO_y = 0.0
    }

    if (msg.msgiNS_GYRO_z !== undefined) {
      resolved.msgiNS_GYRO_z = msg.msgiNS_GYRO_z;
    }
    else {
      resolved.msgiNS_GYRO_z = 0.0
    }

    if (msg.msgiNS_PitchAngle !== undefined) {
      resolved.msgiNS_PitchAngle = msg.msgiNS_PitchAngle;
    }
    else {
      resolved.msgiNS_PitchAngle = 0.0
    }

    if (msg.msgiNS_RollAngle !== undefined) {
      resolved.msgiNS_RollAngle = msg.msgiNS_RollAngle;
    }
    else {
      resolved.msgiNS_RollAngle = 0.0
    }

    if (msg.msgiNS_HeadingPitchAngle !== undefined) {
      resolved.msgiNS_HeadingPitchAngle = msg.msgiNS_HeadingPitchAngle;
    }
    else {
      resolved.msgiNS_HeadingPitchAngle = 0.0
    }

    if (msg.msgiNS_LocatHeight !== undefined) {
      resolved.msgiNS_LocatHeight = msg.msgiNS_LocatHeight;
    }
    else {
      resolved.msgiNS_LocatHeight = 0.0
    }

    if (msg.msgiNS_Time !== undefined) {
      resolved.msgiNS_Time = msg.msgiNS_Time;
    }
    else {
      resolved.msgiNS_Time = 0.0
    }

    if (msg.msgiNS_Latitude !== undefined) {
      resolved.msgiNS_Latitude = msg.msgiNS_Latitude;
    }
    else {
      resolved.msgiNS_Latitude = 0.0
    }

    if (msg.msgiNS_Longitude !== undefined) {
      resolved.msgiNS_Longitude = msg.msgiNS_Longitude;
    }
    else {
      resolved.msgiNS_Longitude = 0.0
    }

    if (msg.msgiNS_NorthSpd !== undefined) {
      resolved.msgiNS_NorthSpd = msg.msgiNS_NorthSpd;
    }
    else {
      resolved.msgiNS_NorthSpd = 0.0
    }

    if (msg.msgiNS_EastSpd !== undefined) {
      resolved.msgiNS_EastSpd = msg.msgiNS_EastSpd;
    }
    else {
      resolved.msgiNS_EastSpd = 0.0
    }

    if (msg.msgiNS_ToGroundSpd !== undefined) {
      resolved.msgiNS_ToGroundSpd = msg.msgiNS_ToGroundSpd;
    }
    else {
      resolved.msgiNS_ToGroundSpd = 0.0
    }

    if (msg.msgiNS_Gpsflag_Pos !== undefined) {
      resolved.msgiNS_Gpsflag_Pos = msg.msgiNS_Gpsflag_Pos;
    }
    else {
      resolved.msgiNS_Gpsflag_Pos = 0
    }

    if (msg.msgiNS_NumSV !== undefined) {
      resolved.msgiNS_NumSV = msg.msgiNS_NumSV;
    }
    else {
      resolved.msgiNS_NumSV = 0
    }

    if (msg.msgiNS_Gpsflag_Heading !== undefined) {
      resolved.msgiNS_Gpsflag_Heading = msg.msgiNS_Gpsflag_Heading;
    }
    else {
      resolved.msgiNS_Gpsflag_Heading = 0
    }

    if (msg.msgiNS_Gps_Age !== undefined) {
      resolved.msgiNS_Gps_Age = msg.msgiNS_Gps_Age;
    }
    else {
      resolved.msgiNS_Gps_Age = 0
    }

    if (msg.msgiNS_Car_Status !== undefined) {
      resolved.msgiNS_Car_Status = msg.msgiNS_Car_Status;
    }
    else {
      resolved.msgiNS_Car_Status = 0
    }

    if (msg.msgiNS_iNS_Status !== undefined) {
      resolved.msgiNS_iNS_Status = msg.msgiNS_iNS_Status;
    }
    else {
      resolved.msgiNS_iNS_Status = 0
    }

    if (msg.msgiNS_Std_Lat !== undefined) {
      resolved.msgiNS_Std_Lat = msg.msgiNS_Std_Lat;
    }
    else {
      resolved.msgiNS_Std_Lat = 0.0
    }

    if (msg.msgiNS_Std_Lon !== undefined) {
      resolved.msgiNS_Std_Lon = msg.msgiNS_Std_Lon;
    }
    else {
      resolved.msgiNS_Std_Lon = 0.0
    }

    if (msg.msgiNS_Std_LocatHeight !== undefined) {
      resolved.msgiNS_Std_LocatHeight = msg.msgiNS_Std_LocatHeight;
    }
    else {
      resolved.msgiNS_Std_LocatHeight = 0.0
    }

    if (msg.msgiNS_Std_Heading !== undefined) {
      resolved.msgiNS_Std_Heading = msg.msgiNS_Std_Heading;
    }
    else {
      resolved.msgiNS_Std_Heading = 0.0
    }

    if (msg.msgUTC_year !== undefined) {
      resolved.msgUTC_year = msg.msgUTC_year;
    }
    else {
      resolved.msgUTC_year = 0
    }

    if (msg.msgUTC_month !== undefined) {
      resolved.msgUTC_month = msg.msgUTC_month;
    }
    else {
      resolved.msgUTC_month = 0
    }

    if (msg.msgUTC_day !== undefined) {
      resolved.msgUTC_day = msg.msgUTC_day;
    }
    else {
      resolved.msgUTC_day = 0
    }

    if (msg.msgUTC_hour !== undefined) {
      resolved.msgUTC_hour = msg.msgUTC_hour;
    }
    else {
      resolved.msgUTC_hour = 0
    }

    if (msg.msgUTC_min !== undefined) {
      resolved.msgUTC_min = msg.msgUTC_min;
    }
    else {
      resolved.msgUTC_min = 0
    }

    if (msg.msgUTC_sec !== undefined) {
      resolved.msgUTC_sec = msg.msgUTC_sec;
    }
    else {
      resolved.msgUTC_sec = 0
    }

    if (msg.msgUTC_msec !== undefined) {
      resolved.msgUTC_msec = msg.msgUTC_msec;
    }
    else {
      resolved.msgUTC_msec = 0
    }

    if (msg.x !== undefined) {
      resolved.x = msg.x;
    }
    else {
      resolved.x = 0.0
    }

    if (msg.y !== undefined) {
      resolved.y = msg.y;
    }
    else {
      resolved.y = 0.0
    }

    return resolved;
    }
};

module.exports = rtkmsg;
