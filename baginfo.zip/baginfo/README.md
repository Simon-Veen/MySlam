# 缺少can_msgs依赖需要安装
- sudo apt-get install ros-kinetic-can-msgs

# pyhton脚本画轨迹时缺少库文件
ModuleNotFoundError: No module named 'matplotlib'
- sudo apt install python3-matplotlib

# 保存成CSV文件时，档位数据乱码问题
原因：由于数据解析原因，需要同时写入车速(float)和档位(int)信息，前者可以正常写入，后者因为格式原因会乱码。
解决：将档位由int转为string类型写入文件。



# 写入时间戳数据时使用科学计数法导致精度丢失
解决：
```cpp
rtkfile.open("rtkTrajectory.csv",ios::app);
rtkfile.setf(ios::fixed, ios::floatfield);
```
# 通过解析CANdbc得到
- 档位信息
	-P 0
	-N 1
    -R 2
    -D 3
