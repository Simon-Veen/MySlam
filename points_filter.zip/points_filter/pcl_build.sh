cd build
rm -rf *
cd ..
catkin_make
source devel/setup.bash


