#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <ctype.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/point_types.h>
#include <pcl/common/time.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <thread>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/register_point_struct.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/PointCloud2.h>
#include "ros/ros.h"
#include <zmq.hpp>
#include "../proto/points.pb.h"
#include <chrono>
#include <sensor_msgs/point_cloud2_iterator.h>
// /*--------初始化参数-----------*/
std::string input_file_name ="/home/xunxu/BYD/data/point2d.csv" ; //"/home/xunxu/point2d.csv"
std::string output_file = "/home/xunxu/BYD/output_point.csv";
bool write_title = 0;
bool Vis_init = 0;
sensor_msgs::PointCloud2 output_msg;
typedef pcl::PointXYZI PointT;

// class zmqnode{
// public:
//   zmqnode(){};
//   ~zmqnode();
//   zmqnode(const zmqnode&) = delete;
//   zmqnode& operator=(const zmqnode&) = delete;
  
//   void zmq_pub(const sensor_msgs::PointCloud2::ConstPtr& msg){
  //   TimedPointCloudData Tpoints;
  //   zmq::context_t context(1);
  //   zmq::socket_t publisher(context,zmq::socket_type::pub);
  //   publisher.bind("tcp://192.168.15.67:8888");
  //   Tpoints.set_timestamp(msg->header.stamp.toSec());
  //   sensor_msgs::PointCloud2Iterator<float> iter_x(*msg, "x");
  //   sensor_msgs::PointCloud2Iterator<float> iter_y(*msg, "y");
  //   sensor_msgs::PointCloud2Iterator<float> iter_z(*msg, "z");
  //   for (; iter_x != iter_x.end(); ++iter_x, ++iter_y, ++iter_z)
  //   {
  //       Vector3f point_data;
  //       point_data.set_x(*iter_x);
  //       point_data.set_y(*iter_y);
  //       point_data.set_z(*iter_z);
  //       Tpoints.add_point_data()->CopyFrom(point_data);
  //   }
  //   std::string serialized_data;
  //   Tpoints.SerializeToString(&serialized_data);
  //   publisher.send(Tpoints);

//  }
// private:


// };

class rosnode{
public:
  rosnode(){
    void pclCallback(sensor_msgs::PointCloud2 msg);
    //ROS Pub & Sub
    sub = nh.subscribe("/lslidar_point_cloud", 10, &rosnode::pclCallback,this);
    pub = nh.advertise<sensor_msgs::PointCloud2>("/filter_points",10);
    //zmqnode zmq_publisher;

  }
  ~rosnode(){};
  rosnode(const rosnode&) = delete;
  rosnode& operator=(const rosnode&) = delete;

  pcl::PointCloud<PointT>::Ptr Points_Filter(pcl::PointCloud<PointT>::Ptr points_cloud)
  {
      pcl::VoxelGrid<PointT> voxel_grid;
      voxel_grid.setInputCloud(points_cloud);
      voxel_grid.setLeafSize(0.2f,0.2f,0.2f);
      pcl::PointCloud<PointT>::Ptr downsampled_cloud(new pcl::PointCloud<PointT>);
      voxel_grid.filter(*downsampled_cloud);
      return downsampled_cloud;
  }
private:
  ros::NodeHandle nh; 
  ros::Publisher pub;
  ros::Subscriber sub;
  void pclCallback(sensor_msgs::PointCloud2 msg)
  {
      auto start_time = std::chrono::steady_clock::now();
      //zmqnode zmq_publisher;
      pcl::PointCloud<PointT>::Ptr cloud(new pcl::PointCloud<PointT>),filter_point;
      pcl::fromROSMsg(msg, *cloud);
      filter_point = Points_Filter(cloud);
      //output_msg=msg;
      pcl::toROSMsg(*filter_point, output_msg);
      pub.publish(output_msg);    
      // boost::shared_ptr<sensor_msgs::PointCloud2> output_msg_ptr =
      // boost::make_shared<sensor_msgs::PointCloud2>(output_msg);

      //zmq_publisher.zmq_pub(output_msg);
      auto end_time = std::chrono::steady_clock::now();
      auto time_cast = end_time-start_time;
      std::cout<<"receive data size:"<< msg.data.size() <<std::endl
               <<"filter data size: "<< output_msg.data.size() <<std::endl
               <<"time cost :"<<std::chrono::duration<double, std::milli>(time_cast).count() <<" ms "<<std::endl;
  }
};

/*--------- 点云可视化---------*/
void point_visualization(pcl::PointCloud<PointT>::Ptr points_cloud,std::string clouds_name)
{
  pcl::visualization::PCLVisualizer::Ptr visualizer(
        new pcl::visualization::PCLVisualizer("points_cloud"));

  if(!Vis_init){
    visualizer->setBackgroundColor(0, 0, 0);
    visualizer->addPointCloud<PointT> (points_cloud, "PointCloud");
    visualizer->setPointCloudRenderingProperties(
        pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "PointCloud");
    visualizer->spinOnce(100000);

    visualizer->addCoordinateSystem(5.0); 
    Vis_init = 1;
    return;
  }
  visualizer->updatePointCloud<PointT>(points_cloud, clouds_name);
  visualizer->spinOnce(10000);
  std::this_thread::sleep_for(std::chrono::milliseconds(100));
}
/*-----------将当前帧的点云写入文件中------------*/
void Points_Write_to_CSV(pcl::PointCloud<PointT>::Ptr points_cloud,std::string filename,int64_t timespamp)
{
  std::ofstream outfile(filename,std::ios::app);

  if(!write_title){
    outfile << "x,y,timestamp" << std::endl;
    write_title = 1;
    //outfile.close();
  }
  for (size_t i = 0; i < points_cloud->points.size(); ++i)
  {
    outfile << points_cloud->points[i].x << "," << points_cloud->points[i].y << ","
     << timespamp << std::endl;
  }
  outfile.close();
}

void Read_CSV_filter(rosnode newnode)
{
    std::ifstream input_file (input_file_name);
    if (!input_file.is_open())
    {
        std::cerr << "Failed to open input file: " << input_file_name << std::endl;
        return;
    }
    pcl::PointCloud<PointT>::Ptr cloud(new pcl::PointCloud<PointT>),filter_point;
    std::string line;
    std::cout << "start reading " << std::endl;
    int64_t last_frame_time = -1, now_frane_time,all_point=0,all_filter_point=0,frame_id=0;
    while (std::getline(input_file, line))
    {
        if (line[0] == 'n' || line[0] == 'p' || line[0]=='x')
          continue;        
        std::stringstream iss(line);
        int64_t timestamp;
        double x, y,z;
        iss >> x >> y >> timestamp;
        now_frane_time = timestamp;
        PointT point;
        point.x = x;
        point.y = y;
        point.z = 0;
        if(last_frame_time!=now_frane_time && last_frame_time!=-1){
            filter_point = newnode.Points_Filter(cloud);
            Points_Write_to_CSV(filter_point, output_file, last_frame_time);
            all_filter_point += filter_point->size();
            all_point += cloud->size();
            //point_visualization(cloud,"before filter");
            point_visualization(filter_point,"after filter");
            // pcl::PointCloud<PointT>::Ptr cloud(new pcl::PointCloud<PointT>);
            std::cout << "frame " << ++frame_id << " has total " << cloud->size() << " points " << std::endl
                      << " after filter total points :" << filter_point->size() << std::endl;
            cloud->clear();
            // break;
        }
        cloud->push_back(point);
        last_frame_time = now_frane_time;
    }
    input_file.close();
    std::cout << "end reading " << std::endl
              << "points size = " << all_point << std::endl
              << "Saved " << all_filter_point << " data points to " << output_file << std::endl;
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "pcl_filter");
    rosnode ros_node;
    //Read_CSV_filter(new_node);
    ros::spin();
    return 0;
}
